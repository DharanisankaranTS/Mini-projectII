import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Blood type enum
export const bloodTypes = [
  'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
] as const;
export type BloodType = typeof bloodTypes[number];

// Organ type enum
export const organTypes = [
  'kidney', 'liver', 'heart', 'lung', 'pancreas', 'cornea', 'intestine'
] as const;
export type OrganType = typeof organTypes[number];

// Donor status enum
export const donorStatuses = [
  'pending', 'verified', 'matched', 'inactive'
] as const;
export type DonorStatus = typeof donorStatuses[number];

// Recipient status enum
export const recipientStatuses = [
  'waiting', 'matched', 'transplanted', 'inactive'
] as const;
export type RecipientStatus = typeof recipientStatuses[number];

// Donor schema
export const donors = pgTable("donors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  bloodType: text("blood_type").notNull(),
  organType: text("organ_type").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  location: text("location").notNull(),
  encryptedData: text("encrypted_data").notNull(),
  iv: text("iv").notNull(),
  dataHash: text("data_hash").notNull(),
  txHash: text("tx_hash"),
  verificationTxHash: text("verification_tx_hash"),
  status: text("status").notNull().default('pending'),
  createdAt: text("created_at").notNull(),
});

export const insertDonorSchema = createInsertSchema(donors).omit({
  id: true,
});

export type InsertDonor = z.infer<typeof insertDonorSchema>;
export type Donor = typeof donors.$inferSelect;

// Recipient schema
export const recipients = pgTable("recipients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  bloodType: text("blood_type").notNull(),
  organNeeded: text("organ_needed").notNull(),
  urgency: integer("urgency").notNull(),
  hospital: text("hospital").notNull(),
  doctor: text("doctor").notNull(),
  location: text("location").notNull(),
  encryptedData: text("encrypted_data").notNull(),
  iv: text("iv").notNull(),
  dataHash: text("data_hash").notNull(),
  txHash: text("tx_hash"),
  status: text("status").notNull().default('waiting'),
  createdAt: text("created_at").notNull(),
});

export const insertRecipientSchema = createInsertSchema(recipients).omit({
  id: true,
});

export type InsertRecipient = z.infer<typeof insertRecipientSchema>;
export type Recipient = typeof recipients.$inferSelect;

// Match schema
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  donorId: integer("donor_id").notNull(),
  recipientId: integer("recipient_id").notNull(),
  compatibilityScore: integer("compatibility_score").notNull(),
  txHash: text("tx_hash"),
  status: text("status").notNull().default('confirmed'),
  matchedAt: text("matched_at").notNull(),
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// Match result interface for AI matching
export interface MatchResult {
  donorId: number;
  recipientId: number;
  donorName: string;
  recipientName: string;
  donorAge: number;
  recipientAge: number;
  donorBloodType: string;
  recipientBloodType: string;
  organType: string;
  score: number;
  distance: number;
  urgencyLevel: number;
  matchedAt: string;
}
