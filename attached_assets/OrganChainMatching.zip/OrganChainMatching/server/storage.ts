import { 
  users, 
  type User, 
  type InsertUser,
  donors,
  recipients,
  matches,
  Donor,
  InsertDonor,
  Recipient,
  InsertRecipient,
  Match,
  InsertMatch
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Donor operations
  getAllDonors(): Promise<Donor[]>;
  getDonorById(id: number): Promise<Donor | undefined>;
  createDonor(donor: InsertDonor): Promise<Donor>;
  updateDonor(id: number, donor: Partial<Donor>): Promise<Donor>;
  deleteDonor(id: number): Promise<void>;
  
  // Recipient operations
  getAllRecipients(): Promise<Recipient[]>;
  getRecipientById(id: number): Promise<Recipient | undefined>;
  createRecipient(recipient: InsertRecipient): Promise<Recipient>;
  updateRecipient(id: number, recipient: Partial<Recipient>): Promise<Recipient>;
  deleteRecipient(id: number): Promise<void>;
  
  // Match operations
  getAllMatches(): Promise<Match[]>;
  getMatchById(id: number): Promise<Match | undefined>;
  getMatchesByDonorId(donorId: number): Promise<Match[]>;
  getMatchesByRecipientId(recipientId: number): Promise<Match[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, match: Partial<Match>): Promise<Match>;
  deleteMatch(id: number): Promise<void>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private donors: Map<number, Donor>;
  private recipients: Map<number, Recipient>;
  private matches: Map<number, Match>;
  
  private userCurrentId: number;
  private donorCurrentId: number;
  private recipientCurrentId: number;
  private matchCurrentId: number;
  
  public sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.donors = new Map();
    this.recipients = new Map();
    this.matches = new Map();
    
    this.userCurrentId = 1;
    this.donorCurrentId = 1;
    this.recipientCurrentId = 1;
    this.matchCurrentId = 1;
    
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with a sample admin user
    this.createUser({
      username: "admin",
      password: "admin123",
    });
    
    // Initialize with some sample donors
    this.createDonor({
      name: "John Doe",
      age: 35,
      bloodType: "O+",
      organType: "kidney",
      email: "john.doe@example.com",
      phone: "555-123-4567",
      location: "New York, NY",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "verified",
      createdAt: new Date().toISOString()
    });
    
    this.createDonor({
      name: "Jane Smith",
      age: 42,
      bloodType: "A-",
      organType: "liver",
      email: "jane.smith@example.com",
      phone: "555-987-6543",
      location: "Los Angeles, CA",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "verified",
      createdAt: new Date().toISOString()
    });
    
    this.createDonor({
      name: "Michael Johnson",
      age: 28,
      bloodType: "B+",
      organType: "heart",
      email: "michael.johnson@example.com",
      phone: "555-456-7890",
      location: "Chicago, IL",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "pending",
      createdAt: new Date().toISOString()
    });
    
    // Initialize with some sample recipients
    this.createRecipient({
      name: "Emily Wilson",
      age: 40,
      bloodType: "O+",
      organNeeded: "kidney",
      urgency: 8,
      hospital: "Memorial Hospital",
      doctor: "Dr. Roberts",
      location: "Boston, MA",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "waiting",
      createdAt: new Date().toISOString()
    });
    
    this.createRecipient({
      name: "David Brown",
      age: 52,
      bloodType: "A+",
      organNeeded: "liver",
      urgency: 9,
      hospital: "General Hospital",
      doctor: "Dr. Johnson",
      location: "San Francisco, CA",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "waiting",
      createdAt: new Date().toISOString()
    });
    
    this.createRecipient({
      name: "Sarah Miller",
      age: 31,
      bloodType: "B-",
      organNeeded: "heart",
      urgency: 10,
      hospital: "University Medical Center",
      doctor: "Dr. Williams",
      location: "Seattle, WA",
      encryptedData: "encrypted-data",
      iv: "initialization-vector",
      dataHash: "data-hash",
      status: "waiting",
      createdAt: new Date().toISOString()
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Donor operations
  async getAllDonors(): Promise<Donor[]> {
    return Array.from(this.donors.values());
  }
  
  async getDonorById(id: number): Promise<Donor | undefined> {
    return this.donors.get(id);
  }
  
  async createDonor(insertDonor: InsertDonor): Promise<Donor> {
    const id = this.donorCurrentId++;
    const donor: Donor = { 
      ...insertDonor, 
      id,
      status: insertDonor.status || 'pending',
      txHash: insertDonor.txHash || null,
      verificationTxHash: insertDonor.verificationTxHash || null
    };
    this.donors.set(id, donor);
    return donor;
  }
  
  async updateDonor(id: number, donorUpdate: Partial<Donor>): Promise<Donor> {
    const existingDonor = await this.getDonorById(id);
    if (!existingDonor) {
      throw new Error(`Donor with ID ${id} not found`);
    }
    
    const updatedDonor = { ...existingDonor, ...donorUpdate };
    this.donors.set(id, updatedDonor);
    return updatedDonor;
  }
  
  async deleteDonor(id: number): Promise<void> {
    this.donors.delete(id);
  }
  
  // Recipient operations
  async getAllRecipients(): Promise<Recipient[]> {
    return Array.from(this.recipients.values());
  }
  
  async getRecipientById(id: number): Promise<Recipient | undefined> {
    return this.recipients.get(id);
  }
  
  async createRecipient(insertRecipient: InsertRecipient): Promise<Recipient> {
    const id = this.recipientCurrentId++;
    const recipient: Recipient = { 
      ...insertRecipient, 
      id,
      status: insertRecipient.status || 'waiting',
      txHash: insertRecipient.txHash || null
    };
    this.recipients.set(id, recipient);
    return recipient;
  }
  
  async updateRecipient(id: number, recipientUpdate: Partial<Recipient>): Promise<Recipient> {
    const existingRecipient = await this.getRecipientById(id);
    if (!existingRecipient) {
      throw new Error(`Recipient with ID ${id} not found`);
    }
    
    const updatedRecipient = { ...existingRecipient, ...recipientUpdate };
    this.recipients.set(id, updatedRecipient);
    return updatedRecipient;
  }
  
  async deleteRecipient(id: number): Promise<void> {
    this.recipients.delete(id);
  }
  
  // Match operations
  async getAllMatches(): Promise<Match[]> {
    return Array.from(this.matches.values());
  }
  
  async getMatchById(id: number): Promise<Match | undefined> {
    return this.matches.get(id);
  }
  
  async getMatchesByDonorId(donorId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      (match) => match.donorId === donorId
    );
  }
  
  async getMatchesByRecipientId(recipientId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      (match) => match.recipientId === recipientId
    );
  }
  
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.matchCurrentId++;
    const match: Match = { 
      ...insertMatch, 
      id,
      status: insertMatch.status || 'pending',
      txHash: insertMatch.txHash || null
    };
    this.matches.set(id, match);
    return match;
  }
  
  async updateMatch(id: number, matchUpdate: Partial<Match>): Promise<Match> {
    const existingMatch = await this.getMatchById(id);
    if (!existingMatch) {
      throw new Error(`Match with ID ${id} not found`);
    }
    
    const updatedMatch = { ...existingMatch, ...matchUpdate };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }
  
  async deleteMatch(id: number): Promise<void> {
    this.matches.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  public sessionStore: session.Store;

  constructor() {
    const PostgresStore = connectPg(session);
    this.sessionStore = new PostgresStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Donor operations
  async getAllDonors(): Promise<Donor[]> {
    return await db.select().from(donors);
  }

  async getDonorById(id: number): Promise<Donor | undefined> {
    const [donor] = await db.select().from(donors).where(eq(donors.id, id));
    return donor;
  }

  async createDonor(insertDonor: InsertDonor): Promise<Donor> {
    const [donor] = await db.insert(donors).values({
      ...insertDonor,
      // Set default values for nullable fields
      status: insertDonor.status || 'pending',
      txHash: insertDonor.txHash || null,
      verificationTxHash: insertDonor.verificationTxHash || null
    }).returning();
    return donor;
  }

  async updateDonor(id: number, donorUpdate: Partial<Donor>): Promise<Donor> {
    const [donor] = await db
      .update(donors)
      .set(donorUpdate)
      .where(eq(donors.id, id))
      .returning();
    
    if (!donor) {
      throw new Error(`Donor with ID ${id} not found`);
    }
    
    return donor;
  }

  async deleteDonor(id: number): Promise<void> {
    await db.delete(donors).where(eq(donors.id, id));
  }

  // Recipient operations
  async getAllRecipients(): Promise<Recipient[]> {
    return await db.select().from(recipients);
  }

  async getRecipientById(id: number): Promise<Recipient | undefined> {
    const [recipient] = await db.select().from(recipients).where(eq(recipients.id, id));
    return recipient;
  }

  async createRecipient(insertRecipient: InsertRecipient): Promise<Recipient> {
    const [recipient] = await db.insert(recipients).values({
      ...insertRecipient,
      // Set default values for nullable fields
      status: insertRecipient.status || 'waiting',
      txHash: insertRecipient.txHash || null
    }).returning();
    return recipient;
  }

  async updateRecipient(id: number, recipientUpdate: Partial<Recipient>): Promise<Recipient> {
    const [recipient] = await db
      .update(recipients)
      .set(recipientUpdate)
      .where(eq(recipients.id, id))
      .returning();
    
    if (!recipient) {
      throw new Error(`Recipient with ID ${id} not found`);
    }
    
    return recipient;
  }

  async deleteRecipient(id: number): Promise<void> {
    await db.delete(recipients).where(eq(recipients.id, id));
  }

  // Match operations
  async getAllMatches(): Promise<Match[]> {
    return await db.select().from(matches);
  }

  async getMatchById(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match;
  }

  async getMatchesByDonorId(donorId: number): Promise<Match[]> {
    return await db.select().from(matches).where(eq(matches.donorId, donorId));
  }

  async getMatchesByRecipientId(recipientId: number): Promise<Match[]> {
    return await db.select().from(matches).where(eq(matches.recipientId, recipientId));
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const [match] = await db.insert(matches).values({
      ...insertMatch,
      // Set default values for nullable fields
      status: insertMatch.status || 'pending',
      txHash: insertMatch.txHash || null
    }).returning();
    return match;
  }

  async updateMatch(id: number, matchUpdate: Partial<Match>): Promise<Match> {
    const [match] = await db
      .update(matches)
      .set(matchUpdate)
      .where(eq(matches.id, id))
      .returning();
    
    if (!match) {
      throw new Error(`Match with ID ${id} not found`);
    }
    
    return match;
  }

  async deleteMatch(id: number): Promise<void> {
    await db.delete(matches).where(eq(matches.id, id));
  }
}

// Use DatabaseStorage with PostgreSQL
export const storage = new DatabaseStorage();

// If you want to use in-memory storage instead, uncomment below:
// export const storage = new MemStorage();
