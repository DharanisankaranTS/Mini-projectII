import crypto from 'crypto';

export const encryptionService = {
  // Generate a secure random key
  generateKey: (): Buffer => {
    return crypto.randomBytes(32); // 256 bits
  },

  // Generate a random IV
  generateIV: (): Buffer => {
    return crypto.randomBytes(16); // 128 bits
  },

  // AES-256-GCM encryption
  encrypt: (data: string, key?: Buffer): { encrypted: string; iv: string; key?: string } => {
    try {
      // Generate key if not provided
      const encKey = key || encryptionService.generateKey();
      
      // Generate IV (Initialization Vector)
      const iv = encryptionService.generateIV();
      
      // Create cipher
      const cipher = crypto.createCipheriv('aes-256-gcm', encKey, iv);
      
      // Encrypt data
      let encrypted = cipher.update(data, 'utf8', 'base64');
      encrypted += cipher.final('base64');
      
      // Get auth tag
      const authTag = cipher.getAuthTag().toString('base64');
      
      // Return encrypted data with IV and auth tag
      return {
        encrypted: `${encrypted}.${authTag}`,
        iv: iv.toString('base64'),
        key: key ? undefined : encKey.toString('base64')
      };
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt data');
    }
  },

  // AES-256-GCM decryption
  decrypt: (encryptedData: string, iv: string, key: string): string => {
    try {
      // Split encrypted data and auth tag
      const [encrypted, authTag] = encryptedData.split('.');
      
      // Convert parameters from base64
      const encKey = Buffer.from(key, 'base64');
      const ivBuffer = Buffer.from(iv, 'base64');
      const authTagBuffer = Buffer.from(authTag, 'base64');
      
      // Create decipher
      const decipher = crypto.createDecipheriv('aes-256-gcm', encKey, ivBuffer);
      decipher.setAuthTag(authTagBuffer);
      
      // Decrypt data
      let decrypted = decipher.update(encrypted, 'base64', 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt data. The provided key may be invalid.');
    }
  },

  // Generate SHA-256 hash
  generateHash: (data: string): string => {
    return crypto.createHash('sha256').update(data).digest('hex');
  },

  // Generate HMAC signature
  generateSignature: (data: string, key: string): string => {
    return crypto.createHmac('sha256', key).update(data).digest('hex');
  },

  // Verify HMAC signature
  verifySignature: (data: string, signature: string, key: string): boolean => {
    const expectedSignature = encryptionService.generateSignature(data, key);
    return crypto.timingSafeEqual(
      Buffer.from(expectedSignature),
      Buffer.from(signature)
    );
  }
};
