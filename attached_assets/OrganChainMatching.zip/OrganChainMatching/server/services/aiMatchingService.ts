import { storage } from '../storage';
import { Donor, Recipient, MatchResult } from '@shared/schema';
import { openaiService } from './openaiService';

// Helper functions for matching
const BLOOD_TYPE_COMPATIBILITY: Record<string, string[]> = {
  "A+": ["A+", "A-", "O+", "O-"],
  "A-": ["A-", "O-"],
  "B+": ["B+", "B-", "O+", "O-"],
  "B-": ["B-", "O-"],
  "AB+": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
  "AB-": ["A-", "B-", "AB-", "O-"],
  "O+": ["O+", "O-"],
  "O-": ["O-"]
};

// Age compatibility (approximate)
const AGE_RANGE_COMPATIBILITY = 20; // ±20 years is preferred

// Calculate distance between two locations (simplified version)
function calculateDistance(location1: string, location2: string): number {
  // In a real implementation, this would use latitude/longitude
  // For simplicity, we're returning a random distance
  return Math.random() * 100 + 10; // 10-110 km
}

// Calculate blood type compatibility
function isBloodTypeCompatible(donorBloodType: string, recipientBloodType: string): boolean {
  return BLOOD_TYPE_COMPATIBILITY[recipientBloodType]?.includes(donorBloodType) || false;
}

// Calculate age compatibility score (0-1)
function calculateAgeCompatibilityScore(donorAge: number, recipientAge: number): number {
  const ageDifference = Math.abs(donorAge - recipientAge);
  return Math.max(0, 1 - (ageDifference / AGE_RANGE_COMPATIBILITY));
}

export const aiMatchingService = {
  // Find potential matches for a specific recipient
  findMatchesForRecipient: async (recipientId: number): Promise<MatchResult[]> => {
    try {
      // Get recipient
      const recipient = await storage.getRecipientById(recipientId);
      if (!recipient) {
        throw new Error(`Recipient with ID ${recipientId} not found`);
      }
      
      // Get all available donors
      const donors = await storage.getAllDonors();
      
      // Filter donors that are available and have matching organ type
      const availableDonors = donors.filter(donor => 
        donor.status === 'verified' && 
        donor.organType === recipient.organNeeded
      );
      
      const potentialMatches: MatchResult[] = [];
      
      // Evaluate each donor for compatibility
      for (const donor of availableDonors) {
        // Check blood type compatibility
        if (!isBloodTypeCompatible(donor.bloodType, recipient.bloodType)) {
          continue;
        }
        
        // Calculate age compatibility score
        const ageScore = calculateAgeCompatibilityScore(donor.age, recipient.age);
        
        // Calculate distance
        const distance = calculateDistance(donor.location, recipient.location);
        
        // Weight factors for scoring
        const weights = {
          age: 0.4,      // Age compatibility
          distance: 0.2,  // Geographic distance
          hla: 0.3,       // HLA matching (simulated)
          other: 0.1      // Other medical factors
        };
        
        // Simulate HLA and other factors
        const hlaScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        const otherScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        
        // Distance score is inversely proportional to distance
        const distanceScore = Math.max(0, 1 - (distance / 500)); // 0-1 score
        
        // Calculate total compatibility score (0-100)
        const totalScore = Math.round(
          (ageScore * weights.age +
          distanceScore * weights.distance +
          hlaScore * weights.hla +
          otherScore * weights.other) * 100
        );
        
        // Add to potential matches if score is above threshold
        if (totalScore >= 50) {
          potentialMatches.push({
            donorId: donor.id,
            recipientId: recipient.id,
            donorName: donor.name,
            recipientName: recipient.name,
            donorAge: donor.age,
            recipientAge: recipient.age,
            donorBloodType: donor.bloodType,
            recipientBloodType: recipient.bloodType,
            organType: donor.organType,
            score: totalScore,
            distance,
            urgencyLevel: recipient.urgency,
            matchedAt: new Date().toISOString()
          });
        }
      }
      
      // Sort matches by score (highest first) and urgency
      return potentialMatches.sort((a, b) => {
        // Prioritize by urgency first
        if (b.urgencyLevel !== a.urgencyLevel) {
          return b.urgencyLevel - a.urgencyLevel;
        }
        // Then by score
        return b.score - a.score;
      });
    } catch (error) {
      console.error(`Error finding matches for recipient ${recipientId}:`, error);
      throw error;
    }
  },

  // Run AI matching algorithm for all recipients
  runGlobalMatching: async () => {
    try {
      // Get all recipients waiting for a match
      const recipients = await storage.getAllRecipients();
      const waitingRecipients = recipients.filter(r => r.status === 'waiting');
      
      let totalMatches = 0;
      let recipientsWithMatches = 0;
      
      // Process each recipient
      for (const recipient of waitingRecipients) {
        const matches = await aiMatchingService.findMatchesForRecipient(recipient.id);
        
        if (matches.length > 0) {
          recipientsWithMatches++;
          totalMatches += matches.length;
        }
      }
      
      return {
        totalRecipients: waitingRecipients.length,
        recipientsWithMatches,
        totalMatches
      };
    } catch (error) {
      console.error('Error running global matching:', error);
      throw error;
    }
  },

  // Check compatibility between specific donor and recipient
  checkCompatibility: async (donorId: number, recipientId: number) => {
    try {
      // Get donor and recipient
      const donor = await storage.getDonorById(donorId);
      const recipient = await storage.getRecipientById(recipientId);
      
      if (!donor) {
        throw new Error(`Donor with ID ${donorId} not found`);
      }
      
      if (!recipient) {
        throw new Error(`Recipient with ID ${recipientId} not found`);
      }
      
      // Check organ type - fundamental requirement
      if (donor.organType !== recipient.organNeeded) {
        return {
          compatible: false,
          reason: 'Organ type mismatch',
          score: 0,
          aiAnalysis: null
        };
      }
      
      // Check blood type compatibility - fundamental requirement
      if (!isBloodTypeCompatible(donor.bloodType, recipient.bloodType)) {
        return {
          compatible: false,
          reason: 'Blood type incompatibility',
          score: 0,
          aiAnalysis: null
        };
      }
      
      // Basic compatibility checks passed, now use advanced AI analysis
      try {
        // First perform basic scoring as a fallback
        const ageScore = calculateAgeCompatibilityScore(donor.age, recipient.age);
        const distance = calculateDistance(donor.location, recipient.location);
        const distanceScore = Math.max(0, 1 - (distance / 500)); // 0-1 score
        
        // Weight factors for scoring
        const weights = {
          age: 0.4,
          distance: 0.2,
          hla: 0.3,
          other: 0.1
        };
        
        // Simulate HLA and other factors for fallback
        const hlaScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        const otherScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        
        // Calculate fallback score (0-100)
        const fallbackScore = Math.round(
          (ageScore * weights.age +
          distanceScore * weights.distance +
          hlaScore * weights.hla +
          otherScore * weights.other) * 100
        );
        
        // Use OpenAI for advanced compatibility analysis
        const aiAnalysis = await openaiService.analyzeCompatibility(donor, recipient);
        
        // Use AI score if available, fallback score otherwise
        const finalScore = aiAnalysis ? aiAnalysis.compatibilityScore : fallbackScore;
        
        return {
          compatible: finalScore >= 60, // Threshold for compatibility
          score: finalScore,
          details: {
            ageScore: Math.round(ageScore * 100),
            distanceScore: Math.round(distanceScore * 100),
            distance: Math.round(distance)
          },
          aiAnalysis: aiAnalysis ? {
            analysis: aiAnalysis.analysis,
            riskFactors: aiAnalysis.riskFactors,
            recommendations: aiAnalysis.recommendations
          } : null
        };
      } catch (aiError) {
        console.warn('AI analysis failed, using basic compatibility scoring:', aiError);
        
        // Fallback to basic compatibility calculation
        const ageScore = calculateAgeCompatibilityScore(donor.age, recipient.age);
        const distance = calculateDistance(donor.location, recipient.location);
        const distanceScore = Math.max(0, 1 - (distance / 500)); // 0-1 score
        
        // Weight factors for scoring
        const weights = {
          age: 0.4,
          distance: 0.2,
          hla: 0.3,
          other: 0.1
        };
        
        // Simulate HLA and other factors
        const hlaScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        const otherScore = Math.random() * 0.8 + 0.2; // 0.2-1.0
        
        // Calculate total compatibility score (0-100)
        const totalScore = Math.round(
          (ageScore * weights.age +
          distanceScore * weights.distance +
          hlaScore * weights.hla +
          otherScore * weights.other) * 100
        );
        
        return {
          compatible: totalScore >= 60, // Threshold for compatibility
          score: totalScore,
          details: {
            ageScore: Math.round(ageScore * 100),
            distanceScore: Math.round(distanceScore * 100),
            hlaScore: Math.round(hlaScore * 100),
            otherScore: Math.round(otherScore * 100),
            distance: Math.round(distance)
          },
          aiAnalysis: null
        };
      }
    } catch (error) {
      console.error(`Error checking compatibility between donor ${donorId} and recipient ${recipientId}:`, error);
      throw error;
    }
  },

  // Get AI model performance metrics
  getModelMetrics: async () => {
    try {
      // In a real implementation, these metrics would be calculated from actual data
      // For now, returning sample metrics
      return {
        accuracy: 94.2,
        precision: 92.7,
        recall: 90.1,
        f1: 91.4
      };
    } catch (error) {
      console.error('Error getting AI model metrics:', error);
      throw error;
    }
  }
};
