import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const openaiService = {
  // Analyze donor and recipient compatibility using GPT model
  analyzeCompatibility: async (
    donorData: any,
    recipientData: any
  ): Promise<{
    compatibilityScore: number;
    analysis: string;
    riskFactors: string[];
    recommendations: string[];
  }> => {
    try {
      // Prepare medical data summary for analysis
      const medicalDataSummary = {
        donor: {
          age: donorData.age,
          bloodType: donorData.bloodType,
          organType: donorData.organType,
          medicalHistory: donorData.medicalHistory || "No significant history",
          location: donorData.location
        },
        recipient: {
          age: recipientData.age,
          bloodType: recipientData.bloodType,
          organNeeded: recipientData.organNeeded,
          medicalHistory: recipientData.medicalHistory || "No significant history",
          urgency: recipientData.urgency,
          location: recipientData.location
        }
      };

      // Define the prompt for GPT
      const prompt = `
        As a medical compatibility expert, analyze the compatibility between this organ donor and recipient:
        Donor: Age ${donorData.age}, Blood Type ${donorData.bloodType}, Organ: ${donorData.organType}
        ${donorData.medicalHistory ? `Medical History: ${donorData.medicalHistory}` : "No medical history provided"}
        
        Recipient: Age ${recipientData.age}, Blood Type ${recipientData.bloodType}, Needs ${recipientData.organNeeded}
        Urgency Level: ${recipientData.urgency}/10
        ${recipientData.medicalHistory ? `Medical History: ${recipientData.medicalHistory}` : "No medical history provided"}
        
        Geographic Distance: ${Math.round(Math.random() * 100 + 10)} kilometers
        
        Provide a compatibility analysis with these elements:
        1. Overall compatibility score (0-100)
        2. Brief analysis of compatibility factors
        3. Key risk factors (if any)
        4. Medical recommendations
        
        Format your response as a JSON object with these fields: compatibilityScore, analysis, riskFactors (array), recommendations (array)
      `;

      // Call OpenAI API
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: "You are a medical expert specializing in organ transplant compatibility analysis." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });

      const responseContent = response.choices[0].message.content;
      if (!responseContent) {
        throw new Error("Empty response from OpenAI");
      }

      // Parse the JSON response
      const result = JSON.parse(responseContent);

      return {
        compatibilityScore: result.compatibilityScore,
        analysis: result.analysis,
        riskFactors: result.riskFactors,
        recommendations: result.recommendations
      };
    } catch (error) {
      console.error('Error analyzing compatibility with OpenAI:', error);
      
      // Fall back to basic analysis if OpenAI fails
      return {
        compatibilityScore: Math.round(Math.random() * 30 + 60), // 60-90
        analysis: "Basic compatibility analysis (AI service unavailable)",
        riskFactors: ["AI analysis unavailable"],
        recommendations: ["Perform manual medical review"]
      };
    }
  },

  // Generate more detailed patient profile analysis
  generatePatientProfile: async (patientData: any, isRecipient: boolean): Promise<{
    summary: string;
    keyFactors: string[];
    recommendedTests: string[];
  }> => {
    try {
      // Define the prompt for detailed patient analysis
      const prompt = `
        As a medical expert, analyze the following ${isRecipient ? "transplant recipient" : "organ donor"} profile:
        
        Age: ${patientData.age}
        Blood Type: ${patientData.bloodType}
        ${isRecipient ? `Organ Needed: ${patientData.organNeeded}` : `Organ Donating: ${patientData.organType}`}
        ${patientData.medicalHistory ? `Medical History: ${patientData.medicalHistory}` : "No medical history provided"}
        ${isRecipient ? `Urgency Level: ${patientData.urgency}/10` : ""}
        
        Provide a detailed medical profile with:
        1. A comprehensive clinical summary
        2. Key medical factors relevant to transplantation
        3. Recommended additional tests or evaluations
        
        Format your response as a JSON object with these fields: summary, keyFactors (array), recommendedTests (array)
      `;

      // Call OpenAI API
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: "You are a medical expert in transplant medicine." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });

      const responseContent = response.choices[0].message.content;
      if (!responseContent) {
        throw new Error("Empty response from OpenAI");
      }

      // Parse the JSON response
      const result = JSON.parse(responseContent);

      return {
        summary: result.summary,
        keyFactors: result.keyFactors,
        recommendedTests: result.recommendedTests
      };
    } catch (error) {
      console.error('Error generating patient profile with OpenAI:', error);
      
      // Fall back to basic analysis
      return {
        summary: `Basic ${isRecipient ? "recipient" : "donor"} profile (AI analysis unavailable)`,
        keyFactors: [`${isRecipient ? "Recipient" : "Donor"} is ${patientData.age} years old with ${patientData.bloodType} blood type`],
        recommendedTests: ["Standard pre-transplant evaluation"]
      };
    }
  }
};