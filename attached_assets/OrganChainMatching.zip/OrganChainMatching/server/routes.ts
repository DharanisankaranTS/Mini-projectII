import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { donorController } from "./controllers/donorController";
import { recipientController } from "./controllers/recipientController";
import { matchingController } from "./controllers/matchingController";
import { blockchainController } from "./controllers/blockchainController";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);

  // Auth middleware for protected routes
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Authentication required" });
  };

  // Public routes (no authentication required)
  app.get("/api/blockchain/status", blockchainController.getStatus);

  // Protected routes (authentication required)
  // Donor routes
  app.get("/api/donors", donorController.getAllDonors);
  app.get("/api/donors/:id", donorController.getDonorById);
  app.post("/api/donors", donorController.createDonor);
  app.put("/api/donors/:id", isAuthenticated, donorController.updateDonor);
  app.delete("/api/donors/:id", isAuthenticated, donorController.deleteDonor);

  // Recipient routes
  app.get("/api/recipients", recipientController.getAllRecipients);
  app.get("/api/recipients/:id", recipientController.getRecipientById);
  app.post("/api/recipients", recipientController.createRecipient);
  app.put("/api/recipients/:id", isAuthenticated, recipientController.updateRecipient);
  app.delete("/api/recipients/:id", isAuthenticated, recipientController.deleteRecipient);

  // Matching routes
  app.get("/api/matching/potential/:recipientId", matchingController.getPotentialMatches);
  app.post("/api/matching/run-ai", isAuthenticated, matchingController.runAIMatching);
  app.post("/api/matching/confirm", isAuthenticated, matchingController.confirmMatch);
  app.get("/api/matching/metrics", matchingController.getAIMetrics);

  // Blockchain routes
  app.get("/api/blockchain/transactions", blockchainController.getTransactions);
  app.post("/api/blockchain/sync", isAuthenticated, blockchainController.syncWithBlockchain);

  // Encryption status route
  app.get("/api/encryption/status", isAuthenticated, async (req, res) => {
    res.json({
      zkProofs: true,
      aesEncryption: true,
      eccKeyPairs: true,
      keyRotationDays: 14
    });
  });

  app.post("/api/encryption/regenerate", isAuthenticated, async (req, res) => {
    // Simulate key regeneration (would actually regenerate keys in a real implementation)
    setTimeout(() => {
      res.json({ success: true });
    }, 1500);
  });

  // Dashboard stats route
  app.get("/api/stats/dashboard", async (req, res) => {
    const donors = await storage.getAllDonors();
    const recipients = await storage.getAllRecipients();
    const matches = await storage.getAllMatches();
    
    const pendingDonors = donors.filter(d => d.status === 'pending');
    
    res.json({
      totalDonors: donors.length,
      totalRecipients: recipients.length,
      successfulMatches: matches.length,
      pendingVerifications: pendingDonors.length,
      donorsIncrease: "12% increase",
      recipientsIncrease: "8% increase",
      matchesIncrease: "15% increase",
      pendingUrgent: `${Math.min(pendingDonors.length, 12)} urgent`
    });
  });

  // Activity chart stats
  app.get("/api/stats/activity", async (req, res) => {
    const days = parseInt(req.query.days as string) || 30;
    
    // Generate dates for the past N days
    const dates = Array.from({ length: days }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (days - i - 1));
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });
    
    // Generate random data for demonstration
    const donations = Array.from({ length: days }, () => Math.floor(Math.random() * 5));
    const recipients = Array.from({ length: days }, () => Math.floor(Math.random() * 7));
    const matches = Array.from({ length: days }, () => Math.floor(Math.random() * 3));
    
    res.json({
      labels: dates,
      donations,
      recipients,
      matches
    });
  });

  app.get("/api/stats/activity-summary", async (req, res) => {
    const days = parseInt(req.query.days as string) || 30;
    
    // In a real implementation, these would be calculated from actual data
    res.json({
      newDonors: 24,
      newRecipients: 37,
      newMatches: 18,
      successRate: "78%"
    });
  });

  app.get("/api/admin/pending-actions", isAuthenticated, async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 10;
    
    // Sample pending actions
    const pendingActions = [
      {
        id: 1,
        type: 'verification',
        title: 'Verify Donor Medical Records',
        description: 'New donor registration pending medical record verification',
        priority: 'medium',
        action: 'Review',
        secondaryAction: 'Postpone'
      },
      {
        id: 2,
        type: 'urgent-match',
        title: 'Urgent Organ Match Found',
        description: 'Kidney match with 92% compatibility requires immediate approval',
        priority: 'high',
        action: 'Urgent Review',
        secondaryAction: 'Details'
      },
      {
        id: 3,
        type: 'ai-update',
        title: 'Update AI Model Parameters',
        description: 'AI model parameters need to be updated for improved matching accuracy',
        priority: 'low',
        action: 'Configure',
        secondaryAction: 'Skip'
      }
    ].slice(0, limit);
    
    res.json({
      actions: pendingActions,
      total: 12
    });
  });

  app.post("/api/admin/pending-actions/:id/:action", isAuthenticated, async (req, res) => {
    const { id, action } = req.params;
    
    // In a real implementation, this would perform the action
    res.json({
      success: true,
      message: `Action ${action} performed on item ${id}`
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
