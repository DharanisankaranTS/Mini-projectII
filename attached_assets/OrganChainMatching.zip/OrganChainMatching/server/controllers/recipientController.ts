import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertRecipientSchema } from '@shared/schema';
import { blockchainService } from '../services/blockchainService';
import { encryptionService } from '../services/encryptionService';

export const recipientController = {
  // Get all recipients
  getAllRecipients: async (req: Request, res: Response) => {
    try {
      const recipients = await storage.getAllRecipients();
      
      // Return only necessary fields for list view
      const recipientList = recipients.map((recipient) => ({
        id: recipient.id,
        name: recipient.name,
        age: recipient.age,
        bloodType: recipient.bloodType,
        organNeeded: recipient.organNeeded,
        urgency: recipient.urgency,
        hospital: recipient.hospital,
        createdAt: recipient.createdAt,
        status: recipient.status
      }));
      
      res.json(recipientList);
    } catch (error: any) {
      console.error('Error fetching recipients:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch recipients' });
    }
  },

  // Get recipient by ID
  getRecipientById: async (req: Request, res: Response) => {
    try {
      const recipient = await storage.getRecipientById(parseInt(req.params.id));
      
      if (!recipient) {
        return res.status(404).json({ message: 'Recipient not found' });
      }
      
      res.json(recipient);
    } catch (error: any) {
      console.error(`Error fetching recipient ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to fetch recipient' });
    }
  },

  // Create new recipient
  createRecipient: async (req: Request, res: Response) => {
    try {
      // Validate request body against schema
      const recipientData = insertRecipientSchema.parse(req.body);
      
      // Verify blockchain transaction
      if (recipientData.txHash) {
        const isValidTx = await blockchainService.verifyTransaction(recipientData.txHash);
        if (!isValidTx) {
          return res.status(400).json({ message: 'Invalid blockchain transaction' });
        }
      }
      
      // Create recipient
      const newRecipient = await storage.createRecipient(recipientData);
      
      // Run AI matching for this new recipient
      try {
        const aiMatchingService = require('../services/aiMatchingService').aiMatchingService;
        await aiMatchingService.findMatchesForRecipient(newRecipient.id);
      } catch (matchingError) {
        console.error('Error finding matches for new recipient:', matchingError);
        // Continue with the response, but log the matching error
      }
      
      res.status(201).json(newRecipient);
    } catch (error: any) {
      console.error('Error creating recipient:', error);
      
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: 'Invalid recipient data', errors: error.errors });
      }
      
      res.status(500).json({ message: error.message || 'Failed to create recipient' });
    }
  },

  // Update recipient
  updateRecipient: async (req: Request, res: Response) => {
    try {
      const recipientId = parseInt(req.params.id);
      
      // Check if recipient exists
      const existingRecipient = await storage.getRecipientById(recipientId);
      if (!existingRecipient) {
        return res.status(404).json({ message: 'Recipient not found' });
      }
      
      // Validate update data
      const updateData = req.body;
      
      // Update recipient
      const updatedRecipient = await storage.updateRecipient(recipientId, updateData);
      
      // If urgency changed, update the matching calculations
      if (existingRecipient.urgency !== updateData.urgency) {
        try {
          const aiMatchingService = require('../services/aiMatchingService').aiMatchingService;
          await aiMatchingService.findMatchesForRecipient(recipientId);
        } catch (matchingError) {
          console.error('Error updating matches for recipient:', matchingError);
          // Continue with the response, but log the matching error
        }
      }
      
      res.json(updatedRecipient);
    } catch (error: any) {
      console.error(`Error updating recipient ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to update recipient' });
    }
  },

  // Delete recipient
  deleteRecipient: async (req: Request, res: Response) => {
    try {
      const recipientId = parseInt(req.params.id);
      
      // Check if recipient exists
      const existingRecipient = await storage.getRecipientById(recipientId);
      if (!existingRecipient) {
        return res.status(404).json({ message: 'Recipient not found' });
      }
      
      // Delete recipient
      await storage.deleteRecipient(recipientId);
      
      res.json({ success: true, message: 'Recipient deleted successfully' });
    } catch (error: any) {
      console.error(`Error deleting recipient ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to delete recipient' });
    }
  }
};
