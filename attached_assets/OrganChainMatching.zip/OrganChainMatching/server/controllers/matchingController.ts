import { Request, Response } from 'express';
import { storage } from '../storage';
import { aiMatchingService } from '../services/aiMatchingService';
import { blockchainService } from '../services/blockchainService';

export const matchingController = {
  // Get potential matches for a recipient
  getPotentialMatches: async (req: Request, res: Response) => {
    try {
      const recipientId = parseInt(req.params.recipientId);
      
      // Check if recipient exists
      const recipient = await storage.getRecipientById(recipientId);
      if (!recipient) {
        return res.status(404).json({ message: 'Recipient not found' });
      }
      
      // Get potential matches
      const matches = await aiMatchingService.findMatchesForRecipient(recipientId);
      
      res.json(matches);
    } catch (error: any) {
      console.error(`Error finding matches for recipient ${req.params.recipientId}:`, error);
      res.status(500).json({ message: error.message || 'Failed to find matches' });
    }
  },

  // Run AI matching for all recipients
  runAIMatching: async (req: Request, res: Response) => {
    try {
      // Run AI matching for all recipients
      const matchResults = await aiMatchingService.runGlobalMatching();
      
      res.json({
        success: true,
        message: 'AI matching completed successfully',
        stats: {
          totalRecipients: matchResults.totalRecipients,
          recipientsWithMatches: matchResults.recipientsWithMatches,
          totalMatches: matchResults.totalMatches
        }
      });
    } catch (error: any) {
      console.error('Error running AI matching:', error);
      res.status(500).json({ message: error.message || 'Failed to run AI matching' });
    }
  },

  // Confirm a match
  confirmMatch: async (req: Request, res: Response) => {
    try {
      const { donorId, recipientId } = req.body;
      
      if (!donorId || !recipientId) {
        return res.status(400).json({ message: 'Donor ID and Recipient ID are required' });
      }
      
      // Check if donor and recipient exist
      const donor = await storage.getDonorById(donorId);
      const recipient = await storage.getRecipientById(recipientId);
      
      if (!donor) {
        return res.status(404).json({ message: 'Donor not found' });
      }
      
      if (!recipient) {
        return res.status(404).json({ message: 'Recipient not found' });
      }
      
      // Check compatibility with AI-enhanced analysis
      const compatibilityCheck = await aiMatchingService.checkCompatibility(donorId, recipientId);
      if (!compatibilityCheck.compatible) {
        return res.status(400).json({ 
          message: 'Donor and recipient are not compatible',
          details: compatibilityCheck.reason || 'Compatibility score below threshold',
          score: compatibilityCheck.score
        });
      }
      
      // Create match data with AI analysis if available
      const matchData = {
        donorId,
        recipientId,
        compatibilityScore: compatibilityCheck.score,
        matchedAt: new Date().toISOString(),
        status: 'confirmed',
        aiAnalysis: compatibilityCheck.aiAnalysis ? JSON.stringify(compatibilityCheck.aiAnalysis) : null
      };
      
      // Create blockchain data payload
      const blockchainData = {
        score: compatibilityCheck.score,
        timestamp: matchData.matchedAt,
        // Include essential analysis info for blockchain verification
        analysis: compatibilityCheck.aiAnalysis ? {
          riskFactors: compatibilityCheck.aiAnalysis.riskFactors.length,
          recommendations: compatibilityCheck.aiAnalysis.recommendations.length
        } : null
      };
      
      // Record match on blockchain
      const txHash = await blockchainService.createMatch(
        donorId.toString(), 
        recipientId.toString(),
        JSON.stringify(blockchainData)
      );
      
      // Save match in database
      const match = await storage.createMatch({
        ...matchData,
        txHash
      });
      
      // Update donor and recipient status
      await storage.updateDonor(donorId, { status: 'matched' });
      await storage.updateRecipient(recipientId, { status: 'matched' });
      
      res.json({
        success: true,
        message: 'Match confirmed successfully',
        matchId: match.id,
        txHash,
        compatibilityScore: compatibilityCheck.score,
        aiAnalysis: compatibilityCheck.aiAnalysis
      });
    } catch (error: any) {
      console.error('Error confirming match:', error);
      res.status(500).json({ message: error.message || 'Failed to confirm match' });
    }
  },

  // Get AI model metrics
  getAIMetrics: async (req: Request, res: Response) => {
    try {
      const metrics = await aiMatchingService.getModelMetrics();
      
      res.json(metrics);
    } catch (error: any) {
      console.error('Error getting AI metrics:', error);
      res.status(500).json({ message: error.message || 'Failed to get AI metrics' });
    }
  }
};
