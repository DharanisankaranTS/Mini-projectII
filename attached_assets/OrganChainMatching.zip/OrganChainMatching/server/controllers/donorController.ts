import { Request, Response } from 'express';
import { storage } from '../storage';
import { Donor, insertDonorSchema } from '@shared/schema';
import { blockchainService } from '../services/blockchainService';
import { encryptionService } from '../services/encryptionService';

export const donorController = {
  // Get all donors
  getAllDonors: async (req: Request, res: Response) => {
    try {
      const donors = await storage.getAllDonors();
      
      // Return only necessary fields for list view
      const donorList = donors.map((donor) => ({
        id: donor.id,
        name: donor.name,
        age: donor.age,
        bloodType: donor.bloodType,
        organType: donor.organType,
        createdAt: donor.createdAt,
        status: donor.status
      }));
      
      res.json(donorList);
    } catch (error: any) {
      console.error('Error fetching donors:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch donors' });
    }
  },

  // Get donor by ID
  getDonorById: async (req: Request, res: Response) => {
    try {
      const donor = await storage.getDonorById(parseInt(req.params.id));
      
      if (!donor) {
        return res.status(404).json({ message: 'Donor not found' });
      }
      
      res.json(donor);
    } catch (error: any) {
      console.error(`Error fetching donor ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to fetch donor' });
    }
  },

  // Create new donor
  createDonor: async (req: Request, res: Response) => {
    try {
      // Validate request body against schema
      const donorData = insertDonorSchema.parse(req.body);
      
      // Verify blockchain transaction
      if (donorData.txHash) {
        const isValidTx = await blockchainService.verifyTransaction(donorData.txHash);
        if (!isValidTx) {
          return res.status(400).json({ message: 'Invalid blockchain transaction' });
        }
      }
      
      // Create donor
      const newDonor = await storage.createDonor(donorData);
      
      res.status(201).json(newDonor);
    } catch (error: any) {
      console.error('Error creating donor:', error);
      
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: 'Invalid donor data', errors: error.errors });
      }
      
      res.status(500).json({ message: error.message || 'Failed to create donor' });
    }
  },

  // Update donor
  updateDonor: async (req: Request, res: Response) => {
    try {
      const donorId = parseInt(req.params.id);
      
      // Check if donor exists
      const existingDonor = await storage.getDonorById(donorId);
      if (!existingDonor) {
        return res.status(404).json({ message: 'Donor not found' });
      }
      
      // Validate update data
      const updateData = req.body;
      
      // Update donor
      const updatedDonor = await storage.updateDonor(donorId, updateData);
      
      // If status changed to verified, register the change on the blockchain
      if (existingDonor.status !== 'verified' && updateData.status === 'verified') {
        try {
          const txHash = await blockchainService.updateDonorStatus(donorId.toString(), 'verified');
          await storage.updateDonor(donorId, { verificationTxHash: txHash });
        } catch (blockchainError) {
          console.error('Error updating donor status on blockchain:', blockchainError);
          // Continue with the response, but log the blockchain error
        }
      }
      
      res.json(updatedDonor);
    } catch (error: any) {
      console.error(`Error updating donor ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to update donor' });
    }
  },

  // Delete donor
  deleteDonor: async (req: Request, res: Response) => {
    try {
      const donorId = parseInt(req.params.id);
      
      // Check if donor exists
      const existingDonor = await storage.getDonorById(donorId);
      if (!existingDonor) {
        return res.status(404).json({ message: 'Donor not found' });
      }
      
      // Delete donor
      await storage.deleteDonor(donorId);
      
      res.json({ success: true, message: 'Donor deleted successfully' });
    } catch (error: any) {
      console.error(`Error deleting donor ${req.params.id}:`, error);
      res.status(500).json({ message: error.message || 'Failed to delete donor' });
    }
  }
};
