import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { BloodType, OrganType } from '@shared/schema';
import { Encryption, generateUniqueId } from '@/lib/encryption';
import { registerDonor } from '@/lib/web3';

const donorFormSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters." }),
  age: z.coerce.number().min(18, { message: "Donor must be at least 18 years old." }).max(100),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  address: z.string().min(5, { message: "Address is required." }),
  city: z.string().min(2, { message: "City is required." }),
  state: z.string().min(2, { message: "State is required." }),
  zipCode: z.string().min(5, { message: "ZIP code is required." }),
  bloodType: z.enum(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const),
  organType: z.enum(['kidney', 'liver', 'heart', 'lung', 'pancreas', 'cornea', 'intestine'] as const),
  medicalHistory: z.string().optional(),
  additionalNotes: z.string().optional(),
  consentToTerms: z.boolean().refine(value => value === true, {
    message: "You must agree to the terms and conditions.",
  }),
});

type DonorFormValues = z.infer<typeof donorFormSchema>;

const DonorRegistration: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, navigate] = useLocation();

  const form = useForm<DonorFormValues>({
    resolver: zodResolver(donorFormSchema),
    defaultValues: {
      name: "",
      age: 30,
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      bloodType: "O+",
      organType: "kidney",
      medicalHistory: "",
      additionalNotes: "",
      consentToTerms: false,
    },
  });

  const onSubmit = async (data: DonorFormValues) => {
    setIsSubmitting(true);
    try {
      // 1. Encrypt sensitive donor data
      const donorData = {
        ...data,
        id: generateUniqueId(),
        createdAt: new Date().toISOString(),
      };
      
      const { ciphertext, iv, key } = await Encryption.encrypt(JSON.stringify(donorData));
      
      // 2. Generate a hash for blockchain storage
      const dataHash = await Encryption.generateHash(JSON.stringify({
        name: data.name,
        bloodType: data.bloodType,
        organType: data.organType,
        timestamp: new Date().toISOString(),
      }));
      
      // 3. Register on blockchain first (will fail if blockchain is not available)
      const blockchainResult = await registerDonor(donorData.id, dataHash);
      if (!blockchainResult.success) {
        throw new Error(`Blockchain registration failed: ${blockchainResult.error}`);
      }
      
      // 4. Save to backend database
      const response = await apiRequest('POST', '/api/donors', {
        name: data.name,
        age: data.age,
        bloodType: data.bloodType,
        organType: data.organType,
        email: data.email,
        phone: data.phone,
        location: `${data.city}, ${data.state}`,
        encryptedData: ciphertext,
        iv: iv,
        dataHash: dataHash,
        txHash: blockchainResult.txHash,
        status: 'pending'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to register donor');
      }
      
      // 5. Encrypt and store the key in localStorage (in production, would use a more secure method)
      localStorage.setItem(`donor_key_${donorData.id}`, key as string);
      
      // 6. Show success message and redirect
      toast({
        title: "Donor Registered Successfully",
        description: "The donor has been registered on the blockchain and in the system.",
      });
      
      // 7. Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/donors'] });
      
      // 8. Navigate to donors list
      navigate('/donors');
    } catch (error: any) {
      console.error('Donor registration error:', error);
      toast({
        title: "Registration Failed",
        description: error.message || "An error occurred during donor registration.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">Donor Registration</h1>
        <p className="mt-1 text-sm text-slate-500">Register a new organ donor in the blockchain-based system</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Donor Information</CardTitle>
          <CardDescription>
            Enter the donor's personal and medical information securely
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Personal Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter full name" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter email" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter phone number" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter street address" {...field} disabled={isSubmitting} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="City" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="State" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ZIP Code</FormLabel>
                        <FormControl>
                          <Input placeholder="ZIP Code" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Medical Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="bloodType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Blood Type</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={isSubmitting}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select blood type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as BloodType[]).map((type) => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="organType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Organ to Donate</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={isSubmitting}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select organ type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {(['kidney', 'liver', 'heart', 'lung', 'pancreas', 'cornea', 'intestine'] as OrganType[]).map((organ) => (
                              <SelectItem key={organ} value={organ}>
                                {organ.charAt(0).toUpperCase() + organ.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="medicalHistory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Medical History</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter relevant medical history"
                          className="h-24"
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormDescription>
                        Include any relevant medical conditions, surgeries, or medications.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter any additional information"
                          className="h-24"
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Separator />
              
              <FormField
                control={form.control}
                name="consentToTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Consent to Terms</FormLabel>
                      <FormDescription>
                        I consent to the storage of my information on the blockchain and confirm my willingness to donate the specified organ.
                      </FormDescription>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="mr-2"
                  onClick={() => navigate('/donors')}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <span className="material-icons animate-spin mr-2">refresh</span>
                      Registering...
                    </>
                  ) : (
                    <>
                      <span className="material-icons mr-2">volunteer_activism</span>
                      Register Donor
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default DonorRegistration;
