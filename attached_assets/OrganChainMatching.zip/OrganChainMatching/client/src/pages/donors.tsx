import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Link } from 'wouter';
import { Donor } from '@shared/schema';

const Donors: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  // Fetch donors
  const { data: donors, isLoading, isError } = useQuery({
    queryKey: ['/api/donors'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/donors', undefined);
      return await response.json() as Donor[];
    }
  });

  // Filter donors based on search term
  const filteredDonors = donors?.filter(donor => 
    donor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    donor.bloodType.includes(searchTerm.toUpperCase()) ||
    donor.organType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getOrganTypeChip = (organType: string) => {
    const colors: Record<string, string> = {
      'kidney': 'bg-blue-100 text-blue-800',
      'liver': 'bg-green-100 text-green-800',
      'heart': 'bg-red-100 text-red-800',
      'lung': 'bg-purple-100 text-purple-800',
      'pancreas': 'bg-amber-100 text-amber-800',
      'cornea': 'bg-indigo-100 text-indigo-800',
      'intestine': 'bg-pink-100 text-pink-800',
    };
    
    return (
      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${colors[organType.toLowerCase()] || 'bg-slate-100 text-slate-800'}`}>
        {organType}
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="pb-5 border-b border-slate-200 mb-6 flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Donor Database</h1>
          <p className="mt-1 text-sm text-slate-500">View and manage all registered organ donors</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Link href="/donor-registration">
            <Button>
              <span className="material-icons text-sm mr-2">add</span>
              Register New Donor
            </Button>
          </Link>
        </div>
      </div>

      <Card className="mb-8">
        <CardHeader className="pb-3">
          <CardTitle>Donor Search</CardTitle>
          <CardDescription>
            Search donors by name, blood type, or organ type
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="Search donors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-md"
            />
            <Button variant="outline" onClick={() => setSearchTerm('')}>
              Clear
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Registered Donors</CardTitle>
          <CardDescription>
            {filteredDonors?.length || 0} donors found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <div className="material-icons animate-spin mr-2">refresh</div>
              <span>Loading donors...</span>
            </div>
          ) : isError ? (
            <div className="text-center py-10 text-red-500">
              <span className="material-icons text-3xl mb-2">error</span>
              <p>Error loading donors. Please try again later.</p>
            </div>
          ) : filteredDonors?.length === 0 ? (
            <div className="text-center py-10 text-slate-500">
              <span className="material-icons text-5xl mb-2">person_search</span>
              <p>No donors found matching your search criteria.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Age</TableHead>
                    <TableHead>Blood Type</TableHead>
                    <TableHead>Organ Type</TableHead>
                    <TableHead>Registered Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDonors?.map((donor) => (
                    <TableRow key={donor.id}>
                      <TableCell className="font-medium">{donor.name}</TableCell>
                      <TableCell>{donor.age}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-slate-100 text-slate-800 rounded-full text-xs font-semibold">
                          {donor.bloodType}
                        </span>
                      </TableCell>
                      <TableCell>{getOrganTypeChip(donor.organType)}</TableCell>
                      <TableCell>{new Date(donor.createdAt).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${donor.status === 'verified' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                          {donor.status.charAt(0).toUpperCase() + donor.status.slice(1)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <span className="material-icons text-sm">visibility</span>
                          </Button>
                          <Button variant="outline" size="sm">
                            <span className="material-icons text-sm">edit</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Donors;
