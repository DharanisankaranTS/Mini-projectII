import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useOrganMatching } from '@/hooks/useOrganMatching';
import { MatchResult, Recipient } from '@shared/schema';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';

const Matches: React.FC = () => {
  const [location, setLocation] = useLocation();
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>("");
  const { executeAIMatching, isRunningMatch, getPotentialMatches, confirmOrganMatch, isLoadingMatches, isConfirming, potentialMatches } = useOrganMatching();
  
  // Parse recipient ID from URL if present
  useEffect(() => {
    const searchParams = new URLSearchParams(location.split('?')[1]);
    const recipientId = searchParams.get('recipientId');
    if (recipientId) {
      setSelectedRecipientId(recipientId);
      fetchMatchesForRecipient(parseInt(recipientId));
    }
  }, [location]);

  // Fetch recipients for dropdown
  const { data: recipients, isLoading: isLoadingRecipients } = useQuery({
    queryKey: ['/api/recipients'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/recipients', undefined);
      return await response.json() as Recipient[];
    }
  });

  // Fetch matches if we have a recipient selected
  const fetchMatchesForRecipient = async (recipientId: number) => {
    try {
      await getPotentialMatches(recipientId);
    } catch (error) {
      console.error('Error fetching matches:', error);
    }
  };

  const handleRunMatching = async () => {
    try {
      const success = await executeAIMatching();
      if (success && selectedRecipientId) {
        // Refresh matches for the selected recipient
        await fetchMatchesForRecipient(parseInt(selectedRecipientId));
      }
    } catch (error) {
      console.error('Error running AI matching:', error);
    }
  };

  const handleRecipientChange = (value: string) => {
    setSelectedRecipientId(value);
    
    // Update URL to reflect the selected recipient
    if (value) {
      setLocation(`/matches?recipientId=${value}`, { replace: true });
      fetchMatchesForRecipient(parseInt(value));
    } else {
      setLocation('/matches', { replace: true });
    }
  };

  const handleConfirmMatch = async (match: MatchResult) => {
    try {
      const success = await confirmOrganMatch(match.donorId, match.recipientId);
      if (success) {
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/recipients'] });
        queryClient.invalidateQueries({ queryKey: ['/api/donors'] });
        
        toast({
          title: 'Match Confirmed',
          description: `Match confirmed between donor #${match.donorId} and recipient #${match.recipientId}`,
          variant: 'default',
        });
      }
    } catch (error) {
      console.error('Error confirming match:', error);
    }
  };

  const getCompatibilityColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-blue-600';
    if (score >= 50) return 'text-amber-600';
    return 'text-red-600';
  };

  const getUrgencyBadge = (urgency: number) => {
    if (urgency >= 8) {
      return <Badge variant="destructive">Critical</Badge>;
    } else if (urgency >= 5) {
      return <Badge variant="default" className="bg-amber-500">High</Badge>;
    } else if (urgency >= 3) {
      return <Badge variant="default" className="bg-blue-500">Medium</Badge>;
    } else {
      return <Badge variant="outline">Low</Badge>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="pb-5 border-b border-slate-200 mb-6 flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Transplant Matching</h1>
          <p className="mt-1 text-sm text-slate-500">Find and confirm organ donor matches for recipients</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            onClick={handleRunMatching} 
            disabled={isRunningMatch}
          >
            <span className={`material-icons text-sm mr-2 ${isRunningMatch ? 'animate-spin' : ''}`}>smart_toy</span>
            {isRunningMatch ? 'Running AI Matching...' : 'Run AI Matching'}
          </Button>
        </div>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Find Matches</CardTitle>
          <CardDescription>
            Select a recipient to view potential donor matches
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="max-w-md">
            <Select value={selectedRecipientId} onValueChange={handleRecipientChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select a recipient" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingRecipients ? (
                  <SelectItem value="loading" disabled>Loading recipients...</SelectItem>
                ) : !recipients || recipients.length === 0 ? (
                  <SelectItem value="none" disabled>No recipients found</SelectItem>
                ) : (
                  recipients.map(recipient => (
                    <SelectItem key={recipient.id} value={recipient.id.toString()}>
                      {recipient.name} - {recipient.organNeeded} ({recipient.bloodType})
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedRecipientId && (
        <Card>
          <CardHeader>
            <CardTitle>Potential Matches</CardTitle>
            <CardDescription>
              {potentialMatches.length === 0 
                ? "No potential matches found" 
                : `${potentialMatches.length} potential matches found for this recipient`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingMatches ? (
              <div className="flex justify-center items-center py-10">
                <div className="material-icons animate-spin mr-2">refresh</div>
                <span>Finding potential matches...</span>
              </div>
            ) : potentialMatches.length === 0 ? (
              <div className="text-center py-10 text-slate-500">
                <span className="material-icons text-5xl mb-2">search_off</span>
                <p>No potential matches found for this recipient.</p>
                <p className="text-sm mt-2">Try running the AI matching algorithm or selecting a different recipient.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Donor</TableHead>
                      <TableHead>Blood Type</TableHead>
                      <TableHead>Age</TableHead>
                      <TableHead>Organ</TableHead>
                      <TableHead>Distance</TableHead>
                      <TableHead>Recipient Urgency</TableHead>
                      <TableHead>Compatibility</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {potentialMatches.map((match) => (
                      <TableRow key={`${match.donorId}-${match.recipientId}`}>
                        <TableCell className="font-medium">{match.donorName}</TableCell>
                        <TableCell>{match.donorBloodType}</TableCell>
                        <TableCell>{match.donorAge}</TableCell>
                        <TableCell>
                          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            {match.organType}
                          </span>
                        </TableCell>
                        <TableCell>{Math.round(match.distance)} km</TableCell>
                        <TableCell>{getUrgencyBadge(match.urgencyLevel)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Progress value={match.score} className="w-16 h-2" />
                            <span className={`text-sm font-medium ${getCompatibilityColor(match.score)}`}>
                              {match.score}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="default" 
                            size="sm"
                            onClick={() => handleConfirmMatch(match)}
                            disabled={isConfirming}
                          >
                            <span className="material-icons text-sm mr-1">handshake</span>
                            Confirm Match
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <p className="text-sm text-slate-500">
              <span className="material-icons text-sm align-text-bottom mr-1">info</span>
              The AI matching algorithm considers blood type compatibility, age, HLA matching, and other medical factors.
            </p>
          </CardFooter>
        </Card>
      )}
    </div>
  );
};

export default Matches;
