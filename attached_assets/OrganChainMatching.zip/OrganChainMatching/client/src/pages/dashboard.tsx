import React, { useState } from 'react';
import StatCard from '@/components/dashboard/StatCard';
import ActivityChart from '@/components/dashboard/ActivityChart';
import BlockchainTransactions from '@/components/dashboard/BlockchainTransactions';
import AIMatchingAnalysis from '@/components/dashboard/AIMatchingAnalysis';
import BlockchainStatus from '@/components/dashboard/BlockchainStatus';
import PendingActions from '@/components/dashboard/PendingActions';
import EncryptionStatus from '@/components/dashboard/EncryptionStatus';
import QuickActions from '@/components/dashboard/QuickActions';
import { Button } from '@/components/ui/button';
import { useOrganMatching } from '@/hooks/useOrganMatching';
import { useBlockchain } from '@/hooks/useBlockchain';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface DashboardStats {
  totalDonors: number;
  totalRecipients: number;
  successfulMatches: number;
  pendingVerifications: number;
  donorsIncrease: string;
  recipientsIncrease: string;
  matchesIncrease: string;
  pendingUrgent: string;
}

const Dashboard: React.FC = () => {
  const { executeAIMatching, isRunningMatch } = useOrganMatching();
  const { isConnected, connectWallet, refreshConnection } = useBlockchain();
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Fetch dashboard stats
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats/dashboard'],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', '/api/stats/dashboard', undefined);
        return await response.json() as DashboardStats;
      } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        // Return default values if API fails
        return {
          totalDonors: 158,
          totalRecipients: 286,
          successfulMatches: 93,
          pendingVerifications: 42,
          donorsIncrease: '12% increase',
          recipientsIncrease: '8% increase',
          matchesIncrease: '15% increase',
          pendingUrgent: '12 urgent'
        };
      }
    }
  });

  const handleRunAIMatching = async () => {
    await executeAIMatching();
  };

  const handleSyncBlockchain = async () => {
    setIsSyncing(true);
    try {
      if (!isConnected) {
        await connectWallet();
      } else {
        await refreshConnection();
      }
      
      // Sync blockchain data
      await apiRequest('POST', '/api/blockchain/sync', undefined);
    } catch (error) {
      console.error('Error syncing with blockchain:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Page Header */}
      <div className="pb-5 border-b border-slate-200 mb-6 flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Administrator Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">Monitor and manage the organ donation and transplantation system</p>
        </div>
        <div className="mt-4 md:mt-0 flex gap-3">
          <Button 
            variant="outline" 
            onClick={handleSyncBlockchain}
            disabled={isSyncing}
          >
            <span className={`material-icons text-sm mr-2 ${isSyncing ? 'animate-spin' : ''}`}>sync</span>
            {isSyncing ? 'Syncing...' : 'Sync with Blockchain'}
          </Button>
          <Button 
            onClick={handleRunAIMatching}
            disabled={isRunningMatch}
          >
            <span className={`material-icons text-sm mr-2 ${isRunningMatch ? 'animate-spin' : ''}`}>smart_toy</span>
            {isRunningMatch ? 'Processing...' : 'Run AI Matching'}
          </Button>
        </div>
      </div>

      {/* Dashboard Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <StatCard
          title="Total Donors"
          value={isLoading ? '...' : stats?.totalDonors.toString() || '0'}
          icon="volunteer_activism"
          color="primary"
          increase={stats?.donorsIncrease}
        />
        <StatCard
          title="Total Recipients"
          value={isLoading ? '...' : stats?.totalRecipients.toString() || '0'}
          icon="personal_injury"
          color="amber"
          increase={stats?.recipientsIncrease}
        />
        <StatCard
          title="Successful Matches"
          value={isLoading ? '...' : stats?.successfulMatches.toString() || '0'}
          icon="handshake"
          color="secondary"
          increase={stats?.matchesIncrease}
        />
        <StatCard
          title="Pending Verifications"
          value={isLoading ? '...' : stats?.pendingVerifications.toString() || '0'}
          icon="pending_actions"
          color="red"
          decreaseText={stats?.pendingUrgent}
        />
      </div>

      {/* Main Dashboard Content - Two Column Layout */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left Column - Charts & Analytics */}
        <div className="lg:col-span-2 space-y-6">
          <ActivityChart />
          <AIMatchingAnalysis />
          <BlockchainTransactions />
        </div>

        {/* Right Column - Recent Activity & Actions */}
        <div className="space-y-6">
          <BlockchainStatus />
          <PendingActions />
          <EncryptionStatus />
          <QuickActions />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
