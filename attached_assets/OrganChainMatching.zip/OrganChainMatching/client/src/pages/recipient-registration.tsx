import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { BloodType, OrganType } from '@shared/schema';
import { Encryption, generateUniqueId } from '@/lib/encryption';
import { registerRecipient } from '@/lib/web3';

const recipientFormSchema = z.object({
  name: z.string().min(3, { message: "Name must be at least 3 characters." }),
  age: z.coerce.number().min(0, { message: "Please enter a valid age." }).max(120),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  bloodType: z.enum(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const),
  organNeeded: z.enum(['kidney', 'liver', 'heart', 'lung', 'pancreas', 'cornea', 'intestine'] as const),
  hospital: z.string().min(3, { message: "Hospital name is required." }),
  address: z.string().min(5, { message: "Address is required." }),
  city: z.string().min(2, { message: "City is required." }),
  state: z.string().min(2, { message: "State is required." }),
  zipCode: z.string().min(5, { message: "ZIP code is required." }),
  urgencyLevel: z.coerce.number().min(1).max(10),
  medicalCondition: z.string().min(10, { message: "Please provide medical condition details." }),
  doctorName: z.string().min(3, { message: "Doctor's name is required." }),
  doctorPhone: z.string().min(10, { message: "Please enter a valid doctor's phone number." }),
  additionalNotes: z.string().optional(),
  consentToTerms: z.boolean().refine(value => value === true, {
    message: "You must agree to the terms and conditions.",
  }),
});

type RecipientFormValues = z.infer<typeof recipientFormSchema>;

const RecipientRegistration: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [, navigate] = useLocation();

  const form = useForm<RecipientFormValues>({
    resolver: zodResolver(recipientFormSchema),
    defaultValues: {
      name: "",
      age: 35,
      email: "",
      phone: "",
      bloodType: "A+",
      organNeeded: "kidney",
      hospital: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      urgencyLevel: 5,
      medicalCondition: "",
      doctorName: "",
      doctorPhone: "",
      additionalNotes: "",
      consentToTerms: false,
    },
  });

  const onSubmit = async (data: RecipientFormValues) => {
    setIsSubmitting(true);
    try {
      // 1. Encrypt sensitive recipient data
      const recipientData = {
        ...data,
        id: generateUniqueId(),
        createdAt: new Date().toISOString(),
      };
      
      const { ciphertext, iv, key } = await Encryption.encrypt(JSON.stringify(recipientData));
      
      // 2. Generate a hash for blockchain storage
      const dataHash = await Encryption.generateHash(JSON.stringify({
        name: data.name,
        bloodType: data.bloodType,
        organNeeded: data.organNeeded,
        urgencyLevel: data.urgencyLevel,
        timestamp: new Date().toISOString(),
      }));
      
      // 3. Register on blockchain first
      const blockchainResult = await registerRecipient(recipientData.id, dataHash);
      if (!blockchainResult.success) {
        throw new Error(`Blockchain registration failed: ${blockchainResult.error}`);
      }
      
      // 4. Save to backend database
      const response = await apiRequest('POST', '/api/recipients', {
        name: data.name,
        age: data.age,
        bloodType: data.bloodType,
        organNeeded: data.organNeeded,
        urgency: data.urgencyLevel,
        hospital: data.hospital,
        location: `${data.city}, ${data.state}`,
        doctor: data.doctorName,
        encryptedData: ciphertext,
        iv: iv,
        dataHash: dataHash,
        txHash: blockchainResult.txHash,
        status: 'waiting'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to register recipient');
      }
      
      // 5. Encrypt and store the key (in production, would use a more secure method)
      localStorage.setItem(`recipient_key_${recipientData.id}`, key as string);
      
      // 6. Show success message and redirect
      toast({
        title: "Recipient Registered Successfully",
        description: "The recipient has been registered on the blockchain and in the system.",
      });
      
      // 7. Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/recipients'] });
      
      // 8. Navigate to recipients list
      navigate('/recipients');
    } catch (error: any) {
      console.error('Recipient registration error:', error);
      toast({
        title: "Registration Failed",
        description: error.message || "An error occurred during recipient registration.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">Recipient Registration</h1>
        <p className="mt-1 text-sm text-slate-500">Register a new organ transplant recipient in the blockchain-based system</p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recipient Information</CardTitle>
          <CardDescription>
            Enter the recipient's personal and medical information securely
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Personal Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter full name" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter email" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter phone number" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter street address" {...field} disabled={isSubmitting} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="City" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="State" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ZIP Code</FormLabel>
                        <FormControl>
                          <Input placeholder="ZIP Code" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Medical Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="bloodType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Blood Type</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={isSubmitting}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select blood type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as BloodType[]).map((type) => (
                              <SelectItem key={type} value={type}>{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="organNeeded"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Organ Needed</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={isSubmitting}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select organ needed" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {(['kidney', 'liver', 'heart', 'lung', 'pancreas', 'cornea', 'intestine'] as OrganType[]).map((organ) => (
                              <SelectItem key={organ} value={organ}>
                                {organ.charAt(0).toUpperCase() + organ.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="hospital"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hospital Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter hospital name" {...field} disabled={isSubmitting} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="urgencyLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Urgency Level (1-10)</FormLabel>
                      <FormControl>
                        <div className="space-y-2">
                          <Slider
                            min={1}
                            max={10}
                            step={1}
                            defaultValue={[field.value]}
                            onValueChange={(vals) => field.onChange(vals[0])}
                            disabled={isSubmitting}
                          />
                          <div className="flex justify-between text-xs text-slate-500">
                            <span>Low (1)</span>
                            <span>Medium (5)</span>
                            <span>Critical (10)</span>
                          </div>
                          <div className="text-center font-medium">
                            Current Value: {field.value}
                          </div>
                        </div>
                      </FormControl>
                      <FormDescription>
                        Select the urgency level for this transplant
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="medicalCondition"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Medical Condition</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe the medical condition requiring transplant"
                          className="h-24"
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="doctorName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Attending Physician</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter doctor's name" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="doctorPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Physician's Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter doctor's phone number" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter any additional information"
                          className="h-24"
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Separator />
              
              <FormField
                control={form.control}
                name="consentToTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Consent to Terms</FormLabel>
                      <FormDescription>
                        I consent to the storage of my information on the blockchain and confirm the accuracy of the provided information.
                      </FormDescription>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="mr-2"
                  onClick={() => navigate('/recipients')}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <span className="material-icons animate-spin mr-2">refresh</span>
                      Registering...
                    </>
                  ) : (
                    <>
                      <span className="material-icons mr-2">personal_injury</span>
                      Register Recipient
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default RecipientRegistration;
