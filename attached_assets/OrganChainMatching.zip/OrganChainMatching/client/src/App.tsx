import { Switch, Route } from "wouter";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import MainLayout from "./components/layout/MainLayout";
import Dashboard from "./pages/dashboard";
import AuthPage from "@/pages/auth-page";
import Donors from "./pages/donors";
import Recipients from "./pages/recipients";
import Matches from "./pages/matches";
import DonorRegistration from "./pages/donor-registration";
import RecipientRegistration from "./pages/recipient-registration";

// Wrapper components for routes that use MainLayout
const DashboardPage = () => (
  <MainLayout>
    <Dashboard />
  </MainLayout>
);

const DonorsPage = () => (
  <MainLayout>
    <Donors />
  </MainLayout>
);

const RecipientsPage = () => (
  <MainLayout>
    <Recipients />
  </MainLayout>
);

const MatchesPage = () => (
  <MainLayout>
    <Matches />
  </MainLayout>
);

const DonorRegistrationPage = () => (
  <MainLayout>
    <DonorRegistration />
  </MainLayout>
);

const RecipientRegistrationPage = () => (
  <MainLayout>
    <RecipientRegistration />
  </MainLayout>
);

const NotFoundPage = () => (
  <MainLayout>
    <NotFound />
  </MainLayout>
);

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/donors" component={DonorsPage} />
      <ProtectedRoute path="/recipients" component={RecipientsPage} />
      <ProtectedRoute path="/matches" component={MatchesPage} />
      <ProtectedRoute path="/donor-registration" component={DonorRegistrationPage} />
      <ProtectedRoute path="/recipient-registration" component={RecipientRegistrationPage} />
      <Route component={NotFoundPage} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}

export default App;
