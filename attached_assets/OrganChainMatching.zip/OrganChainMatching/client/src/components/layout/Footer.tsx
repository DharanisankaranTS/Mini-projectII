import { Link } from 'wouter';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center space-x-6 md:order-2">
            <a href="#" className="text-slate-400 hover:text-slate-500">
              <span className="sr-only">Help Center</span>
              <span className="material-icons">help_outline</span>
            </a>
            <a href="#" className="text-slate-400 hover:text-slate-500">
              <span className="sr-only">Documentation</span>
              <span className="material-icons">description</span>
            </a>
            <a href="#" className="text-slate-400 hover:text-slate-500">
              <span className="sr-only">Settings</span>
              <span className="material-icons">settings</span>
            </a>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-sm text-slate-500">
              &copy; {currentYear} OrganChain. All rights reserved. <span className="hidden md:inline">|</span><br className="md:hidden"/> Powered by Ethereum Blockchain Technology
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
