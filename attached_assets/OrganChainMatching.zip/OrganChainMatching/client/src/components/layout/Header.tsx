import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { initWeb3, getCurrentAccount, getNetworkId } from '@/lib/web3';

const Header = () => {
  const [location] = useLocation();
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [account, setAccount] = useState<string | null>(null);
  const [networkName, setNetworkName] = useState<string>('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  useEffect(() => {
    const checkConnection = async () => {
      try {
        await initWeb3();
        const currentAccount = await getCurrentAccount();
        setAccount(currentAccount);
        setIsConnected(!!currentAccount);

        const networkId = await getNetworkId();
        if (networkId) {
          switch (networkId) {
            case 1:
              setNetworkName('Ethereum Mainnet');
              break;
            case 3:
              setNetworkName('Ropsten Testnet');
              break;
            case 4:
              setNetworkName('Rinkeby Testnet');
              break;
            case 5:
              setNetworkName('Goerli Testnet');
              break;
            case 42:
              setNetworkName('Kovan Testnet');
              break;
            case 1337:
              setNetworkName('Local Testnet');
              break;
            default:
              setNetworkName(`Network ID ${networkId}`);
          }
        }
      } catch (err) {
        console.error('Failed to check connection:', err);
        setIsConnected(false);
      }
    };

    checkConnection();

    // Listen for account changes
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts: string[]) => {
        setAccount(accounts[0] || null);
        setIsConnected(!!accounts[0]);
      });

      window.ethereum.on('chainChanged', () => {
        window.location.reload();
      });
    }

    return () => {
      // Clean up listeners
      if (window.ethereum) {
        window.ethereum.removeAllListeners('accountsChanged');
        window.ethereum.removeAllListeners('chainChanged');
      }
    };
  }, []);

  const connectWallet = async () => {
    try {
      await initWeb3();
      const currentAccount = await getCurrentAccount();
      setAccount(currentAccount);
      setIsConnected(!!currentAccount);
    } catch (err) {
      console.error('Failed to connect wallet:', err);
    }
  };

  const getShortAddress = (address: string): string => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => {
    const isActive = location === href;
    
    return (
      <Link href={href}>
        <div
          className={`${
            isActive
              ? 'border-primary-500 text-primary-600'
              : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700'
          } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium cursor-pointer`}
        >
          {children}
        </div>
      </Link>
    );
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <span className="material-icons text-primary-600 mr-2">hub</span>
              <Link href="/">
                <div className="font-bold text-xl text-primary-700 cursor-pointer">OrganChain</div>
              </Link>
            </div>
            <nav className="hidden sm:ml-6 sm:flex sm:space-x-8" aria-label="Global">
              <NavLink href="/">Dashboard</NavLink>
              <NavLink href="/donors">Donors</NavLink>
              <NavLink href="/recipients">Recipients</NavLink>
              <NavLink href="/matches">Matches</NavLink>
            </nav>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <div className="flex items-center gap-2">
              {isConnected ? (
                <div className="flex items-center bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                  <span className="h-2 w-2 bg-green-500 rounded-full mr-1 animate-pulse"></span>
                  <span>Connected to {networkName}</span>
                </div>
              ) : (
                <Button variant="outline" size="sm" onClick={connectWallet}>
                  Connect Wallet
                </Button>
              )}
              <button type="button" className="bg-white p-1 rounded-full text-slate-400 hover:text-slate-500 focus:outline-none">
                <span className="material-icons">notifications</span>
              </button>
              <div className="ml-3 relative">
                <div>
                  <button type="button" className="bg-white rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500" id="user-menu-button">
                    <span className="sr-only">Open user menu</span>
                    <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-700">
                      {account ? getShortAddress(account).substring(0, 2).toUpperCase() : 'AD'}
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <button 
              type="button" 
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <span className="material-icons">{isMobileMenuOpen ? 'close' : 'menu'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link href="/">
              <div className={`${location === '/' ? 'bg-primary-50 border-primary-500 text-primary-700' : 'border-transparent text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:text-slate-800'} block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}>
                Dashboard
              </div>
            </Link>
            <Link href="/donors">
              <div className={`${location === '/donors' ? 'bg-primary-50 border-primary-500 text-primary-700' : 'border-transparent text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:text-slate-800'} block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}>
                Donors
              </div>
            </Link>
            <Link href="/recipients">
              <div className={`${location === '/recipients' ? 'bg-primary-50 border-primary-500 text-primary-700' : 'border-transparent text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:text-slate-800'} block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}>
                Recipients
              </div>
            </Link>
            <Link href="/matches">
              <div className={`${location === '/matches' ? 'bg-primary-50 border-primary-500 text-primary-700' : 'border-transparent text-slate-600 hover:bg-slate-50 hover:border-slate-300 hover:text-slate-800'} block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}>
                Matches
              </div>
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-slate-200">
            <div className="flex items-center px-4">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-primary-200 flex items-center justify-center text-primary-700">
                  {account ? getShortAddress(account).substring(0, 2).toUpperCase() : 'AD'}
                </div>
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-slate-800">Administrator</div>
                <div className="text-sm font-medium text-slate-500">
                  {account ? getShortAddress(account) : 'Not connected'}
                </div>
              </div>
            </div>
            <div className="mt-3 space-y-1">
              {!isConnected && (
                <button
                  onClick={connectWallet}
                  className="block px-4 py-2 text-base font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100 w-full text-left"
                >
                  Connect Wallet
                </button>
              )}
              <a href="#" className="block px-4 py-2 text-base font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100">
                Your Profile
              </a>
              <a href="#" className="block px-4 py-2 text-base font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100">
                Settings
              </a>
              <a href="#" className="block px-4 py-2 text-base font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100">
                Sign out
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
