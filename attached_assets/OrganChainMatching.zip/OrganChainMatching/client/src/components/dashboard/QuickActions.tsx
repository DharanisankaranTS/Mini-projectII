import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'wouter';

const QuickActions: React.FC = () => {
  return (
    <Card>
      <CardHeader className="px-5 py-4 border-b border-slate-200">
        <CardTitle className="text-lg font-medium text-slate-800">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="p-5 grid grid-cols-2 gap-3">
        <Link href="/donor-registration">
          <div className="flex flex-col items-center justify-center bg-slate-50 p-4 rounded-lg hover:bg-slate-100 transition-colors duration-200 cursor-pointer">
            <span className="material-icons text-primary-600 mb-2">person_add</span>
            <span className="text-sm text-slate-700 text-center">Register Donor</span>
          </div>
        </Link>
        <Link href="/recipient-registration">
          <div className="flex flex-col items-center justify-center bg-slate-50 p-4 rounded-lg hover:bg-slate-100 transition-colors duration-200 cursor-pointer">
            <span className="material-icons text-amber-600 mb-2">personal_injury</span>
            <span className="text-sm text-slate-700 text-center">Register Recipient</span>
          </div>
        </Link>
        <Link href="/matches">
          <div className="flex flex-col items-center justify-center bg-slate-50 p-4 rounded-lg hover:bg-slate-100 transition-colors duration-200 cursor-pointer">
            <span className="material-icons text-secondary-600 mb-2">search</span>
            <span className="text-sm text-slate-700 text-center">Find Match</span>
          </div>
        </Link>
        <Link href="/reports">
          <div className="flex flex-col items-center justify-center bg-slate-50 p-4 rounded-lg hover:bg-slate-100 transition-colors duration-200 cursor-pointer">
            <span className="material-icons text-blue-600 mb-2">summarize</span>
            <span className="text-sm text-slate-700 text-center">Generate Report</span>
          </div>
        </Link>
      </CardContent>
    </Card>
  );
};

export default QuickActions;
