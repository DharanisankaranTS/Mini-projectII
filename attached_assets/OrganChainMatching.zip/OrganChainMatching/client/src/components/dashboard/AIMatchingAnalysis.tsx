import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Chart from 'chart.js/auto';
import { apiRequest } from '@/lib/queryClient';

interface AIStats {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
}

const AIMatchingAnalysis: React.FC = () => {
  const [aiStats, setAiStats] = useState<AIStats>({
    accuracy: 0,
    precision: 0,
    recall: 0,
    f1: 0
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const organChartRef = useRef<HTMLCanvasElement | null>(null);
  const organChartInstance = useRef<Chart | null>(null);
  const regionChartRef = useRef<HTMLCanvasElement | null>(null);
  const regionChartInstance = useRef<Chart | null>(null);

  const fetchAIStats = async () => {
    try {
      const response = await apiRequest('GET', '/api/matching/metrics', undefined);
      return await response.json();
    } catch (error) {
      console.error('Error fetching AI stats:', error);
      // Return default values if API fails
      return {
        accuracy: 94.2,
        precision: 92.7,
        recall: 90.1,
        f1: 91.4
      };
    }
  };

  const initCharts = async () => {
    if (!organChartRef.current || !regionChartRef.current) return;
    
    setIsLoading(true);
    
    try {
      const stats = await fetchAIStats();
      setAiStats(stats);
      
      // Initialize Organ Compatibility Chart
      const organCtx = organChartRef.current.getContext('2d');
      if (organCtx) {
        if (organChartInstance.current) {
          organChartInstance.current.destroy();
        }
        
        organChartInstance.current = new Chart(organCtx, {
          type: 'doughnut',
          data: {
            labels: ['Kidney', 'Liver', 'Heart', 'Lung', 'Pancreas'],
            datasets: [{
              data: [72, 64, 58, 45, 39],
              backgroundColor: [
                'rgba(59, 130, 246, 0.7)',  // blue
                'rgba(16, 185, 129, 0.7)',  // green
                'rgba(245, 158, 11, 0.7)',  // amber
                'rgba(99, 102, 241, 0.7)',  // indigo
                'rgba(236, 72, 153, 0.7)'   // pink
              ],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                  boxWidth: 12,
                  padding: 10,
                  font: {
                    size: 10
                  }
                }
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    const label = context.label || '';
                    const value = context.formattedValue;
                    return `${label}: ${value}% compatibility`;
                  }
                }
              }
            }
          }
        });
      }
      
      // Initialize Regional Allocation Chart
      const regionCtx = regionChartRef.current.getContext('2d');
      if (regionCtx) {
        if (regionChartInstance.current) {
          regionChartInstance.current.destroy();
        }
        
        regionChartInstance.current = new Chart(regionCtx, {
          type: 'polarArea',
          data: {
            labels: ['North', 'South', 'East', 'West', 'Central'],
            datasets: [{
              data: [42, 35, 28, 19, 33],
              backgroundColor: [
                'rgba(59, 130, 246, 0.7)',  // blue
                'rgba(16, 185, 129, 0.7)',  // green
                'rgba(245, 158, 11, 0.7)',  // amber
                'rgba(99, 102, 241, 0.7)',  // indigo
                'rgba(236, 72, 153, 0.7)'   // pink
              ],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                  boxWidth: 12,
                  padding: 10,
                  font: {
                    size: 10
                  }
                }
              }
            },
            scales: {
              r: {
                ticks: {
                  display: false
                }
              }
            }
          }
        });
      }
    } catch (error) {
      console.error('Error initializing charts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initCharts();
    
    return () => {
      if (organChartInstance.current) {
        organChartInstance.current.destroy();
      }
      if (regionChartInstance.current) {
        regionChartInstance.current.destroy();
      }
    };
  }, []);

  const handleAdjustParameters = () => {
    // This would open a modal for AI parameter adjustment
    console.log('Open AI parameter adjustment modal');
  };

  return (
    <Card>
      <CardHeader className="px-5 py-4 border-b border-slate-200">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium text-slate-800">AI Matching Analysis</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-sm text-primary-600 hover:text-primary-800 font-medium flex items-center"
            onClick={handleAdjustParameters}
          >
            <span className="material-icons text-sm mr-1">tune</span>
            Adjust Parameters
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Compatibility Chart */}
          <div>
            <h3 className="text-sm font-medium text-slate-500 mb-3">Organ Compatibility Rates</h3>
            <div className="h-48 flex items-center justify-center bg-slate-50 rounded border border-slate-200 relative">
              {isLoading ? (
                <div className="text-center">
                  <div className="material-icons text-3xl text-slate-300 mb-2 animate-spin">refresh</div>
                  <p className="text-slate-400 text-xs">Loading compatibility data...</p>
                </div>
              ) : (
                <canvas ref={organChartRef} />
              )}
            </div>
          </div>
          
          {/* Region Map */}
          <div>
            <h3 className="text-sm font-medium text-slate-500 mb-3">Regional Allocation Clusters</h3>
            <div className="h-48 flex items-center justify-center bg-slate-50 rounded border border-slate-200 relative">
              {isLoading ? (
                <div className="text-center">
                  <div className="material-icons text-3xl text-slate-300 mb-2 animate-spin">refresh</div>
                  <p className="text-slate-400 text-xs">Loading regional data...</p>
                </div>
              ) : (
                <canvas ref={regionChartRef} />
              )}
            </div>
          </div>
        </div>
        
        {/* AI Model Stats */}
        <div className="mt-5 pt-5 border-t border-slate-200">
          <h3 className="text-sm font-medium text-slate-600 mb-3">AI Model Performance</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-indigo-50 p-3 rounded-lg">
              <div className="text-xs text-indigo-700 font-medium">Accuracy</div>
              <div className="text-xl font-medium text-indigo-900">{aiStats.accuracy}%</div>
            </div>
            <div className="bg-green-50 p-3 rounded-lg">
              <div className="text-xs text-green-700 font-medium">Precision</div>
              <div className="text-xl font-medium text-green-900">{aiStats.precision}%</div>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="text-xs text-blue-700 font-medium">Recall</div>
              <div className="text-xl font-medium text-blue-900">{aiStats.recall}%</div>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg">
              <div className="text-xs text-purple-700 font-medium">F1 Score</div>
              <div className="text-xl font-medium text-purple-900">{aiStats.f1}%</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIMatchingAnalysis;
