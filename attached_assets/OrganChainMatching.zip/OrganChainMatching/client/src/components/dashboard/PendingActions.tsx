import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { Link } from 'wouter';

interface PendingAction {
  id: number;
  type: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  action: string;
  secondaryAction?: string;
}

const PendingActions: React.FC = () => {
  const [pendingActions, setPendingActions] = useState<PendingAction[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [totalCount, setTotalCount] = useState<number>(0);

  const fetchPendingActions = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('GET', '/api/admin/pending-actions?limit=3', undefined);
      const data = await response.json();
      setPendingActions(data.actions);
      setTotalCount(data.total);
    } catch (error) {
      console.error('Error fetching pending actions:', error);
      // Set dummy data for demo purposes
      setPendingActions([
        {
          id: 1,
          type: 'verification',
          title: 'Verify Donor Medical Records',
          description: 'New donor registration pending medical record verification',
          priority: 'medium',
          action: 'Review',
          secondaryAction: 'Postpone'
        },
        {
          id: 2,
          type: 'urgent-match',
          title: 'Urgent Organ Match Found',
          description: 'Kidney match with 92% compatibility requires immediate approval',
          priority: 'high',
          action: 'Urgent Review',
          secondaryAction: 'Details'
        },
        {
          id: 3,
          type: 'ai-update',
          title: 'Update AI Model Parameters',
          description: 'AI model parameters need to be updated for improved matching accuracy',
          priority: 'low',
          action: 'Configure',
          secondaryAction: 'Skip'
        }
      ]);
      setTotalCount(12);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPendingActions();
  }, []);

  const handleAction = async (id: number, action: string) => {
    try {
      await apiRequest('POST', `/api/admin/pending-actions/${id}/${action.toLowerCase()}`, undefined);
      // Remove the action from the list
      setPendingActions(pendingActions.filter(a => a.id !== id));
      setTotalCount(prev => prev - 1);
    } catch (error) {
      console.error(`Error performing ${action} on action ${id}:`, error);
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <span className="material-icons text-red-500">priority_high</span>;
      case 'medium':
        return <span className="material-icons text-amber-500">priority_high</span>;
      case 'low':
        return <span className="material-icons text-blue-500">info</span>;
      default:
        return <span className="material-icons text-blue-500">info</span>;
    }
  };

  const getActionButton = (id: number, action: string, priority: string) => {
    let className = '';
    let icon = '';
    
    if (action.toLowerCase().includes('urgent')) {
      className = 'bg-red-600 hover:bg-red-700';
      icon = 'bolt';
    } else if (action.toLowerCase() === 'review') {
      className = 'bg-primary-600 hover:bg-primary-700';
      icon = '';
    } else if (action.toLowerCase() === 'configure') {
      className = 'bg-blue-600 hover:bg-blue-700';
      icon = '';
    } else {
      className = 'bg-primary-600 hover:bg-primary-700';
      icon = '';
    }
    
    return (
      <Button
        size="sm"
        className={`inline-flex items-center px-3 py-1 border border-transparent text-xs font-medium rounded shadow-sm text-white ${className}`}
        onClick={() => handleAction(id, action)}
      >
        {icon && <span className="material-icons text-xs mr-1">{icon}</span>}
        {action}
      </Button>
    );
  };

  return (
    <Card>
      <CardHeader className="px-5 py-4 border-b border-slate-200">
        <CardTitle className="text-lg font-medium text-slate-800">Pending Actions</CardTitle>
      </CardHeader>
      <div className="divide-y divide-slate-200">
        {isLoading ? (
          <div className="flex justify-center items-center py-10">
            <div className="material-icons animate-spin mr-2">refresh</div>
            <span>Loading pending actions...</span>
          </div>
        ) : pendingActions.length === 0 ? (
          <div className="p-5 text-center text-slate-500">
            <span className="material-icons text-3xl mb-2">check_circle</span>
            <p>No pending actions to display</p>
          </div>
        ) : (
          pendingActions.map((action) => (
            <div className="p-5" key={action.id}>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  {getPriorityIcon(action.priority)}
                </div>
                <div className="ml-3 flex-1">
                  <h3 className="text-sm font-medium text-slate-800">{action.title}</h3>
                  <p className="mt-1 text-sm text-slate-500">
                    {action.description}
                  </p>
                  <div className="mt-3 flex items-center space-x-2">
                    {getActionButton(action.id, action.action, action.priority)}
                    {action.secondaryAction && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="inline-flex items-center px-3 py-1 border border-slate-300 text-xs font-medium rounded text-slate-700 bg-white hover:bg-slate-50"
                        onClick={() => handleAction(action.id, action.secondaryAction || '')}
                      >
                        {action.secondaryAction}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
        <div className="bg-slate-50 px-5 py-3">
          <Link href="/pending-actions">
            <div className="text-sm text-primary-600 hover:text-primary-800 font-medium flex items-center justify-center cursor-pointer">
              View All Pending Actions
              <span className="material-icons text-sm ml-1">arrow_forward</span>
            </div>
          </Link>
        </div>
      </div>
    </Card>
  );
};

export default PendingActions;
