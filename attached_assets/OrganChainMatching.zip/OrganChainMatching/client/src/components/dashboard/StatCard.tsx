import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  color: 'primary' | 'secondary' | 'amber' | 'red' | 'blue' | 'green';
  increase?: string;
  decreaseText?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  color,
  increase,
  decreaseText
}) => {
  const colorClasses = {
    primary: {
      bg: 'bg-primary-100',
      text: 'text-primary-600',
      footer: 'bg-primary-50',
      trend: 'text-primary-600'
    },
    secondary: {
      bg: 'bg-secondary-100',
      text: 'text-secondary-600',
      footer: 'bg-secondary-50',
      trend: 'text-secondary-600'
    },
    amber: {
      bg: 'bg-amber-100',
      text: 'text-amber-600',
      footer: 'bg-amber-50',
      trend: 'text-amber-600'
    },
    red: {
      bg: 'bg-red-100',
      text: 'text-red-600',
      footer: 'bg-red-50',
      trend: 'text-red-600'
    },
    blue: {
      bg: 'bg-blue-100',
      text: 'text-blue-600',
      footer: 'bg-blue-50',
      trend: 'text-blue-600'
    },
    green: {
      bg: 'bg-green-100',
      text: 'text-green-600',
      footer: 'bg-green-50',
      trend: 'text-green-600'
    }
  };

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${colorClasses[color].bg} rounded-md p-3`}>
            <span className={`material-icons ${colorClasses[color].text}`}>{icon}</span>
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-slate-500 truncate">{title}</dt>
              <dd>
                <div className="text-lg font-medium text-slate-900">{value}</div>
              </dd>
            </dl>
          </div>
        </div>
      </div>
      {(increase || decreaseText) && (
        <div className={`${colorClasses[color].footer} px-5 py-2`}>
          <div className={`text-sm flex items-center ${colorClasses[color].trend}`}>
            {increase && (
              <>
                <span className="material-icons text-sm mr-1">trending_up</span>
                <span>{increase}</span> from last month
              </>
            )}
            {decreaseText && (
              <>
                <span className="material-icons text-sm mr-1">priority_high</span>
                <span>{decreaseText}</span>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default StatCard;
