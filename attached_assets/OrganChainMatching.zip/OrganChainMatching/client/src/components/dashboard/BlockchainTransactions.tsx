import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { Link } from 'wouter';

interface Transaction {
  hash: string;
  type: 'Registration' | 'Matching' | 'Update';
  title: string;
  time: string;
  status: 'Confirmed' | 'Pending' | 'Failed';
  icon: string;
  iconColor: string;
}

const BlockchainTransactions: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [totalCount, setTotalCount] = useState<number>(0);

  const fetchTransactions = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('GET', '/api/blockchain/transactions?limit=3', undefined);
      const data = await response.json();
      setTransactions(data.transactions);
      setTotalCount(data.total);
    } catch (error) {
      console.error('Error fetching blockchain transactions:', error);
      // Set dummy data for demo purposes
      setTransactions([
        {
          hash: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
          type: 'Registration',
          title: 'Donor Registration',
          time: '2 minutes ago',
          status: 'Confirmed',
          icon: 'description',
          iconColor: 'text-primary-600'
        },
        {
          hash: '0x3a093a5347f646Bc1eE21CC8a1915cDD0cB3919c',
          type: 'Matching',
          title: 'Match Confirmation',
          time: '15 minutes ago',
          status: 'Confirmed',
          icon: 'handshake',
          iconColor: 'text-amber-600'
        },
        {
          hash: '0xDc64a140Aa3E981100a9becA4E685f962f0cF6C9',
          type: 'Update',
          title: 'Status Update',
          time: '43 minutes ago',
          status: 'Pending',
          icon: 'update',
          iconColor: 'text-blue-600'
        }
      ]);
      setTotalCount(28);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const getStatusClassName = (status: string): string => {
    switch (status) {
      case 'Confirmed':
        return 'bg-green-100 text-green-800';
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'Failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getTypeClassName = (type: string): string => {
    switch (type) {
      case 'Registration':
        return 'bg-primary-100 text-primary-800';
      case 'Matching':
        return 'bg-amber-100 text-amber-800';
      case 'Update':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <Card>
      <CardHeader className="px-5 py-4 border-b border-slate-200">
        <CardTitle className="text-lg font-medium text-slate-800">Recent Blockchain Transactions</CardTitle>
      </CardHeader>
      <div className="overflow-x-auto">
        {isLoading ? (
          <div className="flex justify-center items-center py-10">
            <div className="material-icons animate-spin mr-2">refresh</div>
            <span>Loading transactions...</span>
          </div>
        ) : (
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Transaction</th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Type</th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Time</th>
                <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {transactions.map((tx, index) => (
                <tr key={index}>
                  <td className="px-5 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center">
                      <span className={`material-icons ${tx.iconColor} mr-2 text-sm`}>{tx.icon}</span>
                      <div>
                        <div className="font-medium text-slate-800">{tx.title}</div>
                        <div className="text-xs mono text-slate-500 truncate max-w-xs">{tx.hash}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-slate-500">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTypeClassName(tx.type)}`}>
                      {tx.type}
                    </span>
                  </td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm text-slate-500">
                    {tx.time}
                  </td>
                  <td className="px-5 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClassName(tx.status)}`}>
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <div className="bg-slate-50 px-5 py-3 flex justify-between items-center">
        <div className="text-sm text-slate-500">Showing the latest {transactions.length} of {totalCount} transactions</div>
        <Link href="/transactions">
          <div className="text-sm text-primary-600 hover:text-primary-800 font-medium flex items-center cursor-pointer">
            View All
            <span className="material-icons text-sm ml-1">arrow_forward</span>
          </div>
        </Link>
      </div>
    </Card>
  );
};

export default BlockchainTransactions;
