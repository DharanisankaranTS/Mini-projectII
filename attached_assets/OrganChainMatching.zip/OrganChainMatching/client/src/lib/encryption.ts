import { toast } from '@/hooks/use-toast';

// AES-256 encryption for sensitive data
export class Encryption {
  private static readonly IV_LENGTH = 16; // For AES-256, IV length is 16 bytes
  private static readonly ALGORITHM = 'AES-GCM';
  private static readonly KEY_LENGTH = 256;

  // Generate a random encryption key
  static async generateKey(): Promise<CryptoKey> {
    try {
      return await window.crypto.subtle.generateKey(
        {
          name: this.ALGORITHM,
          length: this.KEY_LENGTH,
        },
        true,
        ['encrypt', 'decrypt']
      );
    } catch (error) {
      console.error('Error generating encryption key:', error);
      throw new Error('Failed to generate encryption key');
    }
  }

  // Export the key as a base64 string for storage
  static async exportKey(key: CryptoKey): Promise<string> {
    try {
      const keyData = await window.crypto.subtle.exportKey('raw', key);
      return this.arrayBufferToBase64(keyData);
    } catch (error) {
      console.error('Error exporting key:', error);
      throw new Error('Failed to export encryption key');
    }
  }

  // Import a key from a base64 string
  static async importKey(keyBase64: string): Promise<CryptoKey> {
    try {
      const keyData = this.base64ToArrayBuffer(keyBase64);
      return await window.crypto.subtle.importKey(
        'raw',
        keyData,
        {
          name: this.ALGORITHM,
          length: this.KEY_LENGTH,
        },
        false,
        ['encrypt', 'decrypt']
      );
    } catch (error) {
      console.error('Error importing key:', error);
      throw new Error('Failed to import encryption key');
    }
  }

  // Encrypt data using AES-256
  static async encrypt(data: string, keyBase64?: string): Promise<{ ciphertext: string; iv: string; key?: string }> {
    try {
      // Generate a new key if none provided
      let key: CryptoKey;
      let exportedKey: string | undefined;
      
      if (keyBase64) {
        key = await this.importKey(keyBase64);
      } else {
        key = await this.generateKey();
        exportedKey = await this.exportKey(key);
      }

      // Generate a random IV
      const iv = window.crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
      
      // Convert data to ArrayBuffer
      const dataBuffer = new TextEncoder().encode(data);
      
      // Encrypt the data
      const encryptedBuffer = await window.crypto.subtle.encrypt(
        {
          name: this.ALGORITHM,
          iv,
        },
        key,
        dataBuffer
      );
      
      // Convert to base64 strings for storage
      const ciphertext = this.arrayBufferToBase64(encryptedBuffer);
      const ivBase64 = this.arrayBufferToBase64(iv);
      
      return {
        ciphertext,
        iv: ivBase64,
        key: exportedKey,
      };
    } catch (error) {
      console.error('Encryption error:', error);
      toast({
        title: 'Encryption Error',
        description: 'Failed to encrypt sensitive data. Please try again.',
        variant: 'destructive',
      });
      throw new Error('Failed to encrypt data');
    }
  }

  // Decrypt data using AES-256
  static async decrypt(ciphertext: string, iv: string, keyBase64: string): Promise<string> {
    try {
      // Import the key
      const key = await this.importKey(keyBase64);
      
      // Convert base64 to ArrayBuffer
      const ciphertextBuffer = this.base64ToArrayBuffer(ciphertext);
      const ivBuffer = this.base64ToArrayBuffer(iv);
      
      // Decrypt the data
      const decryptedBuffer = await window.crypto.subtle.decrypt(
        {
          name: this.ALGORITHM,
          iv: ivBuffer,
        },
        key,
        ciphertextBuffer
      );
      
      // Convert result back to string
      return new TextDecoder().decode(decryptedBuffer);
    } catch (error) {
      console.error('Decryption error:', error);
      toast({
        title: 'Decryption Error',
        description: 'Failed to decrypt data. The encryption key may be invalid.',
        variant: 'destructive',
      });
      throw new Error('Failed to decrypt data');
    }
  }

  // Generate a hash of data for blockchain storage (not encryption, just hashing)
  static async generateHash(data: string): Promise<string> {
    try {
      const msgBuffer = new TextEncoder().encode(data);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      return this.arrayBufferToHex(hashBuffer);
    } catch (error) {
      console.error('Error generating hash:', error);
      throw new Error('Failed to generate data hash');
    }
  }

  // Convert ArrayBuffer to Base64 string
  private static arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  // Convert Base64 string to ArrayBuffer
  private static base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  // Convert ArrayBuffer to Hex string
  private static arrayBufferToHex(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    return Array.from(bytes)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }
}

// Generate a unique ID for use in the system
export const generateUniqueId = (): string => {
  return 'xxxx-xxxx-xxxx-xxxx'.replace(/x/g, () => {
    const r = Math.floor(Math.random() * 16);
    return r.toString(16);
  });
};
