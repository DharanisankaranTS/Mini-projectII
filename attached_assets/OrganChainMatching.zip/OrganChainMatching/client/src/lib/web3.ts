import Web3 from 'web3';
import type { Contract } from 'web3-eth-contract';
import { toast } from '@/hooks/use-toast';

// ABI for the DonorContract
const DONOR_CONTRACT_ABI = [
  {
    "inputs": [
      { "internalType": "string", "name": "donorId", "type": "string" },
      { "internalType": "string", "name": "dataHash", "type": "string" }
    ],
    "name": "registerDonor",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "string", "name": "recipientId", "type": "string" },
      { "internalType": "string", "name": "dataHash", "type": "string" }
    ],
    "name": "registerRecipient",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "string", "name": "donorId", "type": "string" },
      { "internalType": "string", "name": "recipientId", "type": "string" },
      { "internalType": "string", "name": "matchData", "type": "string" }
    ],
    "name": "createMatch",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "string", "name": "donorId", "type": "string" },
      { "internalType": "string", "name": "status", "type": "string" }
    ],
    "name": "updateDonorStatus",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getTotalDonors",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getTotalRecipients",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  }
];

// Use environment variables for contract addresses with appropriate fallbacks
// In Vite, we need to use import.meta.env instead of process.env
const DONOR_CONTRACT_ADDRESS = import.meta.env.VITE_DONOR_CONTRACT_ADDRESS || '0x71C7656EC7ab88b098defB751B7401B5f6d8976F';

let web3Instance: Web3 | null = null;
let donorContract: any = null; // Using any to avoid TypeScript generic issues

// Initialize Web3 and connect to the blockchain
export const initWeb3 = async (): Promise<Web3 | null> => {
  if (web3Instance) return web3Instance;

  try {
    // Check if MetaMask is installed
    if (window.ethereum) {
      web3Instance = new Web3(window.ethereum);
      try {
        // Request account access
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        console.log('Connected to Web3 provider');
        return web3Instance;
      } catch (error) {
        console.error('User denied account access');
        toast({
          title: 'Wallet Connection Error',
          description: 'Please connect your wallet to use blockchain features.',
          variant: 'destructive',
        });
        // Instead of returning null, we'll use a fallback provider for read operations
        web3Instance = new Web3(new Web3.providers.HttpProvider('https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161'));
        return web3Instance;
      }
    } 
    // If no injected web3 instance is detected, fallback to a public provider
    else {
      console.log('No Web3 provider detected, using fallback provider');
      // We'll use Infura's public endpoint for read operations
      web3Instance = new Web3(new Web3.providers.HttpProvider('https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161'));
      return web3Instance;
    }
  } catch (error) {
    console.error('Error initializing Web3:', error);
    toast({
      title: 'Blockchain Connection Error',
      description: 'Failed to connect to blockchain network. Please try again later.',
      variant: 'destructive',
    });
    return null;
  }
};

// Get the donor contract instance
export const getDonorContract = async (): Promise<any> => {
  if (donorContract) return donorContract;

  try {
    const web3 = await initWeb3();
    if (!web3) return null;

    if (!DONOR_CONTRACT_ADDRESS) {
      console.error('Donor contract address not provided');
      toast({
        title: 'Configuration Error',
        description: 'Donor contract address not configured. Please contact administrator.',
        variant: 'destructive',
      });
      return null;
    }

    donorContract = new web3.eth.Contract(
      DONOR_CONTRACT_ABI as any,
      DONOR_CONTRACT_ADDRESS
    );
    return donorContract;
  } catch (error) {
    console.error('Error getting donor contract:', error);
    toast({
      title: 'Contract Error',
      description: 'Failed to load the blockchain contract. Please try again later.',
      variant: 'destructive',
    });
    return null;
  }
};

// Get current account address
export const getCurrentAccount = async (): Promise<string | null> => {
  try {
    const web3 = await initWeb3();
    if (!web3) return null;
    
    const accounts = await web3.eth.getAccounts();
    return accounts[0] || null;
  } catch (error) {
    console.error('Error getting current account:', error);
    return null;
  }
};

// Get current network ID
export const getNetworkId = async (): Promise<number | null> => {
  try {
    const web3 = await initWeb3();
    if (!web3) return null;
    
    // Using as any to avoid TypeScript errors with bigint to number conversion
    const networkId = await web3.eth.net.getId() as any;
    return Number(networkId);
  } catch (error) {
    console.error('Error getting network ID:', error);
    return null;
  }
};

// Register a donor on the blockchain
export const registerDonor = async (
  donorId: string, 
  dataHash: string
): Promise<{ success: boolean; txHash?: string; error?: string }> => {
  try {
    const contract = await getDonorContract();
    if (!contract) throw new Error('Contract not initialized');
    
    const account = await getCurrentAccount();
    if (!account) throw new Error('No account connected');
    
    const result = await contract.methods.registerDonor(donorId, dataHash).send({ from: account });
    return { success: true, txHash: result.transactionHash };
  } catch (error: any) {
    console.error('Error registering donor:', error);
    return { success: false, error: error.message };
  }
};

// Register a recipient on the blockchain
export const registerRecipient = async (
  recipientId: string, 
  dataHash: string
): Promise<{ success: boolean; txHash?: string; error?: string }> => {
  try {
    const contract = await getDonorContract();
    if (!contract) throw new Error('Contract not initialized');
    
    const account = await getCurrentAccount();
    if (!account) throw new Error('No account connected');
    
    const result = await contract.methods.registerRecipient(recipientId, dataHash).send({ from: account });
    return { success: true, txHash: result.transactionHash };
  } catch (error: any) {
    console.error('Error registering recipient:', error);
    return { success: false, error: error.message };
  }
};

// Create a match on the blockchain
export const createMatch = async (
  donorId: string,
  recipientId: string,
  matchData: string
): Promise<{ success: boolean; txHash?: string; error?: string }> => {
  try {
    const contract = await getDonorContract();
    if (!contract) throw new Error('Contract not initialized');
    
    const account = await getCurrentAccount();
    if (!account) throw new Error('No account connected');
    
    const result = await contract.methods.createMatch(donorId, recipientId, matchData).send({ from: account });
    return { success: true, txHash: result.transactionHash };
  } catch (error: any) {
    console.error('Error creating match:', error);
    return { success: false, error: error.message };
  }
};

// Listen for blockchain events
export const subscribeToEvents = (eventName: string, callback: (error: Error, event: any) => void) => {
  getDonorContract().then((contract) => {
    if (contract && contract.events && contract.events[eventName]) {
      try {
        contract.events[eventName]({}, callback);
      } catch (error) {
        console.error(`Error subscribing to ${eventName} events:`, error);
      }
    } else {
      console.log(`Contract or event ${eventName} not available, skipping subscription`);
    }
  }).catch(error => {
    console.error('Failed to get contract for event subscription:', error);
  });
};

// Get blockchain status for UI display (with fallbacks)
export const getBlockchainStatus = async (): Promise<{
  isConnected: boolean;
  account: string | null;
  networkId: number | null;
  networkName: string;
}> => {
  try {
    const isConnected = window.ethereum !== undefined;
    const account = await getCurrentAccount();
    const networkId = await getNetworkId();
    
    let networkName = 'Unknown';
    
    // Map network ID to name
    switch (networkId) {
      case 1:
        networkName = 'Ethereum Mainnet';
        break;
      case 3:
        networkName = 'Ropsten Testnet';
        break;
      case 4:
        networkName = 'Rinkeby Testnet';
        break;
      case 5:
        networkName = 'Goerli Testnet';
        break;
      case 42:
        networkName = 'Kovan Testnet';
        break;
      case 56:
        networkName = 'Binance Smart Chain';
        break;
      case 97:
        networkName = 'BSC Testnet';
        break;
      case 137:
        networkName = 'Polygon Mainnet';
        break;
      case 80001:
        networkName = 'Mumbai Testnet';
        break;
      default:
        networkName = `Network ID: ${networkId || 'Unknown'}`;
    }
    
    return {
      isConnected,
      account,
      networkId,
      networkName
    };
  } catch (error) {
    console.error('Error getting blockchain status:', error);
    
    // Return a fallback state that won't break the UI
    return {
      isConnected: false,
      account: null,
      networkId: null,
      networkName: 'Not connected to blockchain'
    };
  }
};

// For TypeScript support
declare global {
  interface Window {
    ethereum?: any;
  }
}
