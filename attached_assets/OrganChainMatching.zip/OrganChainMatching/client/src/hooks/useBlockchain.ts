import { useState, useEffect, useCallback } from 'react';
import { initWeb3, getCurrentAccount, getNetworkId } from '@/lib/web3';
import { toast } from '@/hooks/use-toast';

interface BlockchainStatus {
  isConnected: boolean;
  account: string | null;
  networkId: number | null;
  networkName: string;
  contractAddress: string;
  isLoading: boolean;
  error: string | null;
}

export const useBlockchain = () => {
  const [status, setStatus] = useState<BlockchainStatus>({
    isConnected: false,
    account: null,
    networkId: null,
    networkName: '',
    contractAddress: '',
    isLoading: true,
    error: null
  });

  const getNetworkName = (networkId: number): string => {
    switch (networkId) {
      case 1:
        return 'Ethereum Mainnet';
      case 3:
        return 'Ropsten Testnet';
      case 4:
        return 'Rinkeby Testnet';
      case 5:
        return 'Goerli Testnet';
      case 42:
        return 'Kovan Testnet';
      case 1337:
        return 'Local Testnet';
      default:
        return `Network ID ${networkId}`;
    }
  };

  const checkConnection = useCallback(async () => {
    setStatus(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      await initWeb3();
      const account = await getCurrentAccount();
      const networkId = await getNetworkId();
      
      let networkName = '';
      if (networkId) {
        networkName = getNetworkName(networkId);
      }
      
      setStatus({
        isConnected: !!account,
        account,
        networkId,
        networkName,
        contractAddress: process.env.DONOR_CONTRACT_ADDRESS || '',
        isLoading: false,
        error: null
      });
    } catch (error: any) {
      console.error('Error checking blockchain connection:', error);
      setStatus({
        isConnected: false,
        account: null,
        networkId: null,
        networkName: '',
        contractAddress: '',
        isLoading: false,
        error: error?.message || 'Failed to connect to blockchain'
      });
    }
  }, []);

  const connectWallet = useCallback(async () => {
    try {
      await initWeb3();
      await checkConnection();
      
      if (!status.account) {
        throw new Error('Failed to connect wallet. Please try again.');
      }
      
      toast({
        title: 'Wallet Connected',
        description: `Connected to ${status.networkName} with account ${status.account.substring(0, 6)}...${status.account.substring(status.account.length - 4)}`,
        variant: 'default',
      });
    } catch (error: any) {
      console.error('Error connecting wallet:', error);
      toast({
        title: 'Connection Failed',
        description: error?.message || 'Failed to connect wallet. Please try again.',
        variant: 'destructive',
      });
    }
  }, [status.account, status.networkName, checkConnection]);

  useEffect(() => {
    checkConnection();
    
    // Listen for account changes
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts: string[]) => {
        setStatus(prev => ({
          ...prev,
          isConnected: !!accounts[0],
          account: accounts[0] || null
        }));
      });

      window.ethereum.on('chainChanged', () => {
        checkConnection();
      });
    }
    
    return () => {
      // Clean up listeners
      if (window.ethereum) {
        window.ethereum.removeAllListeners('accountsChanged');
        window.ethereum.removeAllListeners('chainChanged');
      }
    };
  }, [checkConnection]);

  return {
    ...status,
    connectWallet,
    refreshConnection: checkConnection
  };
};
