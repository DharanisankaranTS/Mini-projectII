import { useState, useCallback } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { runAIMatching, findPotentialMatches, confirmMatch } from '@/lib/ai-matching';
import { MatchResult } from '@shared/schema';

export const useOrganMatching = () => {
  const [isRunningMatch, setIsRunningMatch] = useState<boolean>(false);
  const [isLoadingMatches, setIsLoadingMatches] = useState<boolean>(false);
  const [isConfirming, setIsConfirming] = useState<boolean>(false);
  const [potentialMatches, setPotentialMatches] = useState<MatchResult[]>([]);

  // Run the AI matching algorithm
  const executeAIMatching = useCallback(async (): Promise<boolean> => {
    setIsRunningMatch(true);
    try {
      const success = await runAIMatching();
      return success;
    } catch (error) {
      console.error('Error in AI matching execution:', error);
      toast({
        title: 'AI Matching Error',
        description: 'An error occurred while running the matching algorithm.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsRunningMatch(false);
    }
  }, []);

  // Find potential matches for a recipient
  const getPotentialMatches = useCallback(async (recipientId: number): Promise<MatchResult[]> => {
    setIsLoadingMatches(true);
    try {
      const matches = await findPotentialMatches(recipientId);
      setPotentialMatches(matches);
      return matches;
    } catch (error) {
      console.error('Error finding potential matches:', error);
      toast({
        title: 'Matching Error',
        description: 'Failed to find potential matches for the recipient.',
        variant: 'destructive',
      });
      setPotentialMatches([]);
      return [];
    } finally {
      setIsLoadingMatches(false);
    }
  }, []);

  // Confirm a match between donor and recipient
  const confirmOrganMatch = useCallback(async (donorId: number, recipientId: number): Promise<boolean> => {
    setIsConfirming(true);
    try {
      const success = await confirmMatch(donorId, recipientId);
      
      if (success) {
        // Remove the confirmed match from potential matches
        setPotentialMatches(prev => prev.filter(match => 
          match.donorId !== donorId || match.recipientId !== recipientId
        ));
      }
      
      return success;
    } catch (error) {
      console.error('Error confirming match:', error);
      toast({
        title: 'Confirmation Error',
        description: 'Failed to confirm the organ match.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsConfirming(false);
    }
  }, []);

  return {
    isRunningMatch,
    isLoadingMatches,
    isConfirming,
    potentialMatches,
    executeAIMatching,
    getPotentialMatches,
    confirmOrganMatch
  };
};
